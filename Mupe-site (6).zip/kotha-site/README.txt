==========================================================
 MUPE v3.4
==========================================================

DEPLOY (Netlify)
  Drag and drop this folder (or the zip) onto Netlify. No build step needed.

ONE-TIME SETUP FOR GROUPS + MEETINGS (about 1 minute)
  1) Firebase Console > Firestore Database > Rules
  2) Copy everything from firestore.rules, paste it there and press Publish.
  (1:1 chat, calls and login keep working without this. Without the rules,
   creating a Group or Meeting shows a permission message.)

PHONE LOGIN + NOTES + STORIES (v3.4)
  1) Firebase Console > Authentication > Sign-in method > Phone > Enable.
  2) Authentication > Settings > Authorized domains: add your Netlify domain.
  3) Authentication > Settings > SMS region policy: allow Bangladesh (BD).
  4) For testing without real SMS: Phone > "Phone numbers for testing".
  5) Publish the NEW firestore.rules (adds "notes" and "stories").
  Notes and stories vanish after 24 hours. Location: exact GPS spot when the phone
  gives a sharp fix (<= 300 m, see EXACT_ACC in js/config.js), otherwise district only.

USERNAMES + PHONE NUMBER (v3.1)
  Usernames are unique: the app checks live while typing and reserves the name
  in a "usernames" collection. Phone number is optional (sign-up or Profile) and
  is stored privately at users/{uid}/private/contact. Both need the latest
  firestore.rules to be published (same step as above).

DELETE ACCOUNT (v3.2)
  Settings > Delete account. The user re-verifies with Google, then the profile,
  username reservation and private phone are deleted and the sign-in itself is
  removed. Signing in again with the same Gmail creates a brand-new account.
  Needs the latest firestore.rules (users/{uid} delete is allowed for the owner).

SENDING DOCUMENTS (PDF / ZIP)
  Cloudinary > Settings > Security > "Restricted media types":
  enable (allow) "PDF and ZIP files delivery", otherwise PDFs will not open.

CALL QUALITY
  Add a TURN server in js/config.js (TURN_SERVERS), e.g. Cloudflare Realtime TURN
  or the Metered.ca free plan. This lets calls connect between mobile data and WiFi.

OWNER BADGE
  When you sign in with mdfardinfahim.me@gmail.com you get a verified badge.
  To show it to everyone: Settings > About > "Copy my UID", then put it in
  OWNER.uids = ["your-uid"] inside js/config.js.

BRANDING
  Name: Mupe. Logo: lime speech-bubble "M" (favicon.svg + icons/*.png).
  Animated logo: js/utils.js (logoSVG) and css/style.css ("Logo animation" section).

NOTE
  Firebase / Cloudinary identifiers in js/config.js still contain the old project
  id ("kotha-app-43d1f", "kotha_unsigned"). They are backend IDs, not visible to
  users, and must stay unchanged or the app will lose its database connection.
