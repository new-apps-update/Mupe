import {
  auth, db, googleProvider, signInWithPopup, signInWithRedirect, getRedirectResult,
  onAuthStateChanged, signOut, doc, getDoc, setDoc, getDocs, collection, query, where, limit, serverTimestamp, runTransaction,
  RecaptchaVerifier, signInWithPhoneNumber, deleteField
} from "./firebase.js";
import { DIVISIONS, OWNER, EXACT_ACC } from "./config.js";
import { S } from "./state.js";
import { $, avatar, toast, makeKeywords, injectIcons, setOwnerSelf } from "./utils.js";
import { geohashEncode, getPosition, reverseGeocode, divisionOf } from "./geo.js";

const show = id => { ["#login", "#onboard"].forEach(s => $(s).classList.add("hidden")); if (id) $(id).classList.remove("hidden"); };

/* ---------- location helpers ---------- */
// one select with every district, grouped by division
export function fillDistrictSelect(sel, value = "") {
  sel.innerHTML = '<option value="">Choose district</option>'
    + Object.entries(DIVISIONS).map(([div, list]) => `<optgroup label="${div}">${list.map(d => `<option ${d[0] === value ? "selected" : ""}>${d[0]}</option>`).join("")}</optgroup>`).join("")
    + `<option value="Other" ${value === "Other" ? "selected" : ""}>Outside Bangladesh</option>`;
}

// Ask the phone for its GPS position. exact = the fix is sharp enough to show a precise spot;
// otherwise only the district is used.
export async function detectLocation({ areaSel, note, btn }) {
  const old = btn?.innerHTML; if (btn) { btn.disabled = true; btn.textContent = "Locating..."; }
  try {
    const p = await getPosition();
    const g = await reverseGeocode(p.lat, p.lng);
    const exact = p.acc <= EXACT_ACC;
    if (g.district && areaSel) areaSel.value = g.district;
    if (note) note.textContent = exact
      ? `📍 ${[g.locality, g.district].filter(Boolean).join(", ")} · people nearby will see your exact spot`
      : `📍 ${g.district || "Your district"} · exact GPS is not available right now, so only your district will be shown`;
    return { ...p, ...g, exact, locality: exact ? g.locality : "" };
  } catch (e) {
    toast(e.message || "Could not get your location", "err");
    return null;
  } finally { if (btn) { btn.disabled = false; btn.innerHTML = old; } }
}
const r5 = n => Math.round(n * 1e5) / 1e5;
// profile fields for a detectLocation() result: exact point when possible, district only otherwise
export function locFields(r) {
  const f = { area: r.district || "", division: r.division || "", locOn: true };
  if (r.exact) { f.geo = { lat: r5(r.lat), lng: r5(r.lng) }; f.geohash = geohashEncode(r.lat, r.lng, 7); f.locality = r.locality || ""; }
  else { f.geo = deleteField(); f.geohash = deleteField(); f.locality = ""; }
  return f;
}
export const districtFields = area => ({ area, division: area === "Other" ? "" : divisionOf(area), locality: "", locOn: true, geo: deleteField(), geohash: deleteField() });

/* ---------- username + phone helpers ---------- */
export const USERNAME_RE = /^[a-z0-9_.]{3,20}$/;
export const normUsername = s => String(s || "").trim().toLowerCase().replace(/^@/, "");
// true when nobody else owns this username
export async function usernameFree(name, uid) {
  try { const r = await getDoc(doc(db, "usernames", name)); if (r.exists() && r.data().uid !== uid) return false; } catch { /* rules not published yet: fall back to the profile query */ }
  const found = await getDocs(query(collection(db, "users"), where("usernameLower", "==", name), limit(2)));
  return found.docs.every(d => d.id === uid);
}
// atomically claim a username so two people can never end up with the same one
export async function reserveUsername(name, uid) {
  try {
    await runTransaction(db, async tx => {
      const ref = doc(db, "usernames", name), snap = await tx.get(ref);
      if (snap.exists() && snap.data().uid !== uid) throw Object.assign(new Error("taken"), { code: "username-taken" });
      tx.set(ref, { uid, at: serverTimestamp() });
    });
  } catch (e) { if (e.code === "username-taken") throw e; /* rules not published yet: the query check above still protects most cases */ }
}
// phone: keep digits and a leading +; 01XXXXXXXXX is read as a Bangladesh number
export function parsePhone(raw) {
  let p = String(raw || "").replace(/[\s\-().]/g, "");
  if (!p) return { ok: true, value: "" };
  if (/^01\d{9}$/.test(p)) p = "+880" + p.slice(1);
  else if (/^8801\d{9}$/.test(p)) p = "+" + p;
  return /^\+?\d{8,15}$/.test(p) ? { ok: true, value: p.startsWith("+") ? p : "+" + p } : { ok: false, value: "" };
}
export const phoneRef = uid => doc(db, "users", uid, "private", "contact");
export async function loadPhone(uid) { try { const s = await getDoc(phoneRef(uid)); return s.exists() ? (s.data().phone || "") : ""; } catch { return ""; } }
export async function savePhone(uid, phone) { await setDoc(phoneRef(uid), { phone, updatedAt: serverTimestamp() }, { merge: true }); }

/* ---------- phone sign-in (SMS code) ---------- */
let verifier = null;
export function freshVerifier() {
  try { verifier?.clear(); } catch { /* ignore */ }
  const holder = $("#recaptcha"); holder.innerHTML = "";
  verifier = new RecaptchaVerifier(auth, holder, { size: "invisible" });
  return verifier;
}
export function authErr(e) {
  const c = e?.code || "";
  if (c === "auth/invalid-phone-number") return "That phone number looks wrong. Use 01XXXXXXXXX or +country code.";
  if (c === "auth/too-many-requests") return "Too many attempts. Please wait a while and try again.";
  if (c === "auth/invalid-verification-code") return "Wrong code. Check the SMS and try again.";
  if (c === "auth/code-expired" || c === "auth/session-expired") return "This code expired. Send a new one.";
  if (c === "auth/operation-not-allowed") return "Phone sign-in is not enabled in Firebase yet.";
  if (c === "auth/quota-exceeded") return "SMS limit reached for today. Try again later or use Google.";
  if (c === "auth/captcha-check-failed" || c === "auth/missing-app-credential") return "Security check failed. Refresh the page and try again.";
  if (c === "auth/unauthorized-domain") return "This website's domain is not authorized in Firebase yet.";
  if (c === "auth/network-request-failed") return "No internet connection.";
  if (c === "auth/billing-not-enabled") return "Phone sign-in needs the Firebase Blaze plan for real numbers.";
  if (c === "auth/popup-closed-by-user" || c === "auth/cancelled-popup-request") return "";
  return "Something went wrong" + (c ? " (" + c.replace("auth/", "") + ")" : "") + ". Please try again.";
}

function initPhoneLogin() {
  const err = m => { $("#lgError").textContent = m || ""; };
  const stepStart = $("#lgStart"), stepCode = $("#lgCode");
  const sendBtn = $("#lgSend"), verBtn = $("#lgVerify"), resend = $("#lgResend");
  let confirmation = null, timer = 0;
  const countdown = () => {
    clearInterval(timer); let n = 30; resend.disabled = true; resend.textContent = `Resend in ${n}s`;
    timer = setInterval(() => { n--; if (n <= 0) { clearInterval(timer); resend.disabled = false; resend.textContent = "Resend code"; } else resend.textContent = `Resend in ${n}s`; }, 1000);
  };
  const send = async () => {
    const ph = parsePhone($("#lgPhone").value);
    if (!ph.ok || !ph.value) return err("Enter a valid phone number.");
    err(""); sendBtn.disabled = true; sendBtn.textContent = "Sending...";
    try {
      confirmation = await signInWithPhoneNumber(auth, ph.value, freshVerifier());
      $("#lgSentTo").textContent = ph.value;
      stepStart.classList.add("hidden"); stepCode.classList.remove("hidden");
      $("#lgOtp").value = ""; $("#lgOtp").focus(); countdown();
    } catch (e) { console.warn(e); err(authErr(e)); try { verifier?.clear(); } catch { /* ignore */ } }
    finally { sendBtn.disabled = false; sendBtn.textContent = "Send code"; }
  };
  const verify = async () => {
    const code = $("#lgOtp").value.replace(/\D/g, "");
    if (code.length !== 6) return err("Enter the 6-digit code.");
    err(""); verBtn.disabled = true; verBtn.textContent = "Verifying...";
    try { await confirmation.confirm(code); }
    catch (e) { err(authErr(e)); }
    finally { verBtn.disabled = false; verBtn.textContent = "Verify & continue"; }
  };
  sendBtn.onclick = send;
  $("#lgPhone").addEventListener("keydown", e => { if (e.key === "Enter") send(); });
  verBtn.onclick = verify;
  $("#lgOtp").addEventListener("input", e => { e.target.value = e.target.value.replace(/\D/g, "").slice(0, 6); if (e.target.value.length === 6) verify(); });
  resend.onclick = () => { if (!resend.disabled) send(); };
  $("#lgBack").onclick = () => { clearInterval(timer); err(""); confirmation = null; stepCode.classList.add("hidden"); stepStart.classList.remove("hidden"); };
}

export function initAuth({ onReady, onLoggedOut }) {
  getRedirectResult(auth).catch(e => { if (e?.code && e.code !== "auth/no-auth-event") console.warn(e); });
  initPhoneLogin();

  const gbtn = $("#googleBtn");
  gbtn.addEventListener("click", async () => {
    gbtn.classList.add("loading"); gbtn.disabled = true; $("#lgError").textContent = "";
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      if (e.code === "auth/popup-blocked" || e.code === "auth/operation-not-supported-in-this-environment") {
        try { await signInWithRedirect(auth, googleProvider); return; } catch (e2) { e = e2; }
      }
      $("#lgError").textContent = authErr(e);
    } finally { gbtn.classList.remove("loading"); gbtn.disabled = false; }
  });

  $("#obLogout").addEventListener("click", () => signOut(auth));

  onAuthStateChanged(auth, async user => {
    if (!user) { show("#login"); $("#lgStart").classList.remove("hidden"); $("#lgCode").classList.add("hidden"); onLoggedOut(); return; }
    S.isOwner = !!user.email && user.email.toLowerCase() === OWNER.email.toLowerCase();
    setOwnerSelf(S.isOwner ? user.uid : null);
    try {
      const snap = await getDoc(doc(db, "users", user.uid));
      const data = snap.exists() ? snap.data() : null;
      if (!data || !data.username) { showOnboarding(user, data, onReady); return; }
      show(null);
      onReady(user, data);
    } catch (e) {
      console.error(e);
      toast("Could not load your profile. Check Firestore rules and database.", "err", 6000);
      show("#login");
    }
  });
}

function showOnboarding(user, existing, onReady) {
  show("#onboard");
  const nameIn = $("#obName"), uIn = $("#obUser"), uNote = $("#obUserNote"), sel = $("#obArea"), note = $("#obGeoNote"), err = m => { $("#obError").textContent = m; };
  let photo = existing?.photoURL || user.photoURL || "";
  const paint = () => { $("#obAvatar").innerHTML = avatar({ displayName: nameIn.value || user.displayName || "?", photoURL: photo }, 96); $("#obPhotoTxt").textContent = photo ? "Change photo" : "Add photo"; };
  nameIn.value = existing?.displayName || user.displayName || "";
  nameIn.oninput = () => { if (!photo) paint(); };
  paint();

  // profile picture
  $("#obPhotoBtn").onclick = () => $("#obPhotoInput").click();
  $("#obPhotoInput").onchange = async e => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    const b = $("#obPhotoBtn"); b.disabled = true; $("#obPhotoTxt").textContent = "Uploading...";
    try { const { uploadFile, compressImage } = await import("./attach.js"); photo = (await uploadFile(await compressImage(f, 600), "photo")).secure_url; }
    catch (er) { toast(er.message || "Upload failed", "err"); }
    b.disabled = false; paint();
  };

  // username (live availability)
  const base = (user.email || user.displayName || "user").split("@")[0].toLowerCase().replace(/[^a-z0-9_.]/g, "").slice(0, 14);
  uIn.value = existing?.username || (base.length >= 3 ? base : "user" + Math.floor(Math.random() * 9000 + 1000));
  let uTimer = 0, uSeq = 0;
  const checkLive = () => {
    clearTimeout(uTimer); const name = normUsername(uIn.value), seq = ++uSeq;
    uNote.className = "u-note"; uNote.textContent = "";
    if (!name) return;
    if (!USERNAME_RE.test(name)) { uNote.className = "u-note bad"; uNote.textContent = "3-20 letters, numbers, dot or underscore"; return; }
    uNote.className = "u-note wait"; uNote.textContent = "Checking...";
    uTimer = setTimeout(async () => {
      try { const free = await usernameFree(name, user.uid); if (seq !== uSeq) return; uNote.className = "u-note " + (free ? "ok" : "bad"); uNote.textContent = free ? "✓ Available" : "✗ Already taken"; }
      catch { if (seq === uSeq) { uNote.className = "u-note"; uNote.textContent = ""; } }
    }, 450);
  };
  uIn.oninput = checkLive; checkLive();

  // phone: already known when signed in by SMS
  const phoneKnown = user.phoneNumber || "";
  $("#obPhoneWrap").classList.toggle("hidden", !!phoneKnown);
  $("#obPhone").value = "";
  if (!phoneKnown) loadPhone(user.uid).then(p => { if (p && !$("#obPhone").value) $("#obPhone").value = p; });

  // location (optional): exact GPS spot, or just a district
  fillDistrictSelect(sel, existing?.area || "");
  note.textContent = "";
  let loc = null;
  sel.onchange = () => { loc = null; note.textContent = ""; };
  $("#obGps").onclick = async () => { const r = await detectLocation({ areaSel: sel, note, btn: $("#obGps") }); if (r) loc = r; };

  err("");
  const btn = $("#obSave"); btn.disabled = false;
  btn.onclick = async () => {
    const name = nameIn.value.trim(), username = normUsername(uIn.value), ph = parsePhone($("#obPhone").value);
    if (name.length < 2) return err("Please enter your name.");
    if (!USERNAME_RE.test(username)) return err("Username: 3-20 letters, numbers, dot or underscore.");
    if (!phoneKnown && !ph.ok) return err("Enter a valid phone number, for example +8801XXXXXXXXX (or leave it empty).");
    btn.disabled = true; err("");
    try {
      if (!(await usernameFree(username, user.uid))) { err("This username is already taken. Try another one."); btn.disabled = false; return; }
      try { await reserveUsername(username, user.uid); } catch { err("This username was just taken by someone else. Try another one."); btn.disabled = false; return; }
      const profile = {
        uid: user.uid, displayName: name, nameLower: name.toLowerCase(),
        username, usernameLower: username, keywords: makeKeywords(name, username),
        photoURL: photo, bio: existing?.bio || "Hey there! I am on Mupe 👋",
        online: true, lastSeen: serverTimestamp()
      };
      if (loc) Object.assign(profile, locFields(loc));
      else if (sel.value) Object.assign(profile, districtFields(sel.value));
      else Object.assign(profile, { area: "", division: "", locality: "", locOn: false });
      if (!existing) Object.assign(profile, { contacts: [], blocked: [], createdAt: serverTimestamp() });
      await setDoc(doc(db, "users", user.uid), profile, { merge: true });
      const phoneToSave = phoneKnown || ph.value;
      if (phoneToSave) { try { await savePhone(user.uid, phoneToSave); } catch { toast("Profile saved, but the phone number could not be stored. Publish the latest firestore.rules, then add it from Profile.", "err", 6000); } }
      const fresh = await getDoc(doc(db, "users", user.uid));
      show(null);
      onReady(user, fresh.data());
    } catch (e) {
      console.error(e);
      err("Could not save profile: " + (e.code || e.message));
      btn.disabled = false;
    }
  };
  injectIcons();
}

export const logout = () => signOut(auth);
