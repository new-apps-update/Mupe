import {
  db, doc, getDoc, updateDoc, addDoc, collection, query, where, orderBy, limitToLast,
  onSnapshot, serverTimestamp, writeBatch, arrayUnion, arrayRemove, increment, deleteField
} from "./firebase.js";
import { S } from "./state.js";
import { QUICK_REACTIONS, EMOJI_GROUPS, OWNER } from "./config.js";
import {
  $, $$, esc, avatar, icon, injectIcons, toast, chatIdOf, timeShort, dayLabel, listTime, presenceText,
  isOnline, lastMs, fmtDur, beep, makeKeywords, openModal, closeModal, linkify, fmtSize, fileExt, docTone,
  nameHtml, isOwnerUser, ownerBadge, colorOf, haptic, isCoarse, isMobile, copyText
} from "./utils.js";
import { startCall } from "./call.js";
import { startMeetingFromChat, joinMeeting } from "./meet.js";
import { mapHtml, mapsLink, fmtDistance, distanceKm } from "./geo.js";
import { initAttach, uploadFile, showFilePreview } from "./attach.js";
import { notify, prefs } from "./prefs.js";
import { showGroupInfo, newGroupModal } from "./groups.js";
import { logout } from "./auth.js";

export const ms = t => t?.toMillis?.() ?? 0;
const safeUrl = u => (typeof u === "string" && /^https:\/\//i.test(u)) ? u : "";

/* =====================  USERS CACHE  ===================== */
const ucache = new Map();
export async function getUser(uid, maxAge = 60000) {
  const c = ucache.get(uid);
  if (c && Date.now() - c.t < maxAge) return c.u;
  try {
    const s = await getDoc(doc(db, "users", uid));
    const u = s.exists() ? { id: s.id, ...s.data() } : null;
    ucache.set(uid, { u, t: Date.now() });
    return u;
  } catch (e) { console.warn("getUser", e); return c?.u || null; }
}
export const cacheUser = u => { if (u?.id) ucache.set(u.id, { u, t: Date.now() }); return u; };
export const userRef = () => doc(db, "users", S.uid);
const myList = k => S.me?.[k] || [];

/* =====================  CHAT LIST  ===================== */
let chatsUnsub = null, firstChatSnap = true, listAnimated = false, chatFilter = "all";
const prevUnread = new Map();

const itemTitle = it => it.isGroup ? (it.data.name || "Group") : (it.user?.displayName || "User");
const itemAv = it => it.isGroup ? { isGroup: true, displayName: it.data.name || "Group", photoURL: it.data.photoURL } : it.user;

export function startChatList() {
  const q = query(collection(db, "chats"), where("participants", "array-contains", S.uid));
  chatsUnsub = onSnapshot(q, async snap => {
    const items = snap.docs.map(d => {
      const data = d.data();
      S.knownChats.add(d.id);
      const isGroup = !!data.isGroup;
      return { id: d.id, data, isGroup, otherId: isGroup ? null : (data.participants || []).find(p => p !== S.uid) };
    });
    const incoming = [];
    items.forEach(it => {
      const n = it.data.unread?.[S.uid] || 0;
      const prev = prevUnread.get(it.id) || 0;
      if (!firstChatSnap && n > prev && it.data.lastSenderId !== S.uid) incoming.push(it);
      prevUnread.set(it.id, n);
    });
    await Promise.all(items.filter(i => !i.isGroup).map(async it => { it.user = await getUser(it.otherId, 120000); }));
    S.chatItems = items;
    renderChatList();
    autoContacts(items);
    updateBadge();
    incoming.forEach(it => {
      if (!it.isGroup && S.me?.blocked?.includes(it.otherId)) return;
      if (myList("muted").includes(it.id)) return;
      const open = S.chatId === it.id && document.visibilityState === "visible";
      if (open) return;
      const body = (it.isGroup && it.data.lastSenderName ? it.data.lastSenderName + ": " : "") + (it.data.lastMessage || "");
      beep("in");
      toast(`${itemTitle(it)}: ${body}`.slice(0, 90));
      notify(itemTitle(it), body, { icon: itemAv(it)?.photoURL, tag: it.id, onclick: () => openConversation({ chatId: it.id }) });
    });
    firstChatSnap = false;
  }, e => console.error("chat list", e));
}
export function stopChatList() { chatsUnsub?.(); chatsUnsub = null; firstChatSnap = true; prevUnread.clear(); listAnimated = false; }

function autoContacts(items) {
  const have = new Set(S.me?.contacts || []);
  const add = items.filter(i => !i.isGroup).map(i => i.otherId).filter(id => id && !have.has(id));
  if (add.length) updateDoc(userRef(), { contacts: arrayUnion(...add) }).catch(() => {});
}
function updateBadge() {
  const blocked = new Set(S.me?.blocked || []), muted = new Set(myList("muted")), arch = new Set(myList("archived"));
  const total = S.chatItems.reduce((a, it) => a + ((it.otherId && blocked.has(it.otherId)) || muted.has(it.id) || arch.has(it.id) ? 0 : (it.data.unread?.[S.uid] || 0)), 0);
  const b = $("#chatsBadge");
  b.textContent = total > 99 ? "99+" : total; b.classList.toggle("hidden", !total);
  ["#railBadge", "#bnBadge"].forEach(s => $(s)?.classList.toggle("hidden", !total));
  document.title = total ? `(${total}) Mupe` : "Mupe - Talk freely";
  try { navigator.setAppBadge?.(total || 0); if (!total) navigator.clearAppBadge?.(); } catch { /* ignore */ }
}
function previewOf(p) {
  if (p.type === "image") return "📷 Photo";
  if (p.type === "video") return "🎥 Video";
  if (p.type === "audio") return "🎤 Voice message";
  if (p.type === "file") return "📄 " + (p.fileName || "Document");
  if (p.type === "location") return "📍 Location";
  if (p.type === "poll") return "📊 " + (p.question || "Poll");
  if (p.type === "meeting") return "📹 Meeting";
  if (p.type === "call") return (p.callType === "video" ? "📹 " : "📞 ") + (p.outcome === "completed" ? "Call" : "Missed call");
  return (p.text || "").slice(0, 80);
}

export function setChatFilter(f) {
  chatFilter = f;
  $$("#chatFilters .fchip").forEach(c => c.classList.toggle("active", c.dataset.f === f));
  renderChatList();
}

export function renderChatList() {
  const box = $("#chatList");
  const blocked = new Set(myList("blocked")), pinned = myList("pinned"), muted = new Set(myList("muted")), arch = new Set(myList("archived"));
  let items = S.chatItems.filter(it => (it.isGroup || it.user) && !(it.otherId && blocked.has(it.otherId)));
  items = items.filter(it => chatFilter === "archived" ? arch.has(it.id) : !arch.has(it.id));
  if (chatFilter === "unread") items = items.filter(it => (it.data.unread?.[S.uid] || 0) > 0);
  if (chatFilter === "groups") items = items.filter(it => it.isGroup);
  items.sort((a, b) => (pinned.includes(b.id) - pinned.includes(a.id)) || (ms(b.data.updatedAt) - ms(a.data.updatedAt)));
  if (!items.length) {
    const msg = chatFilter === "unread" ? "No unread chats. You are all caught up! ✨" : chatFilter === "groups" ? "No groups yet.<br>Tap the group icon above to create one." : chatFilter === "archived" ? "No archived chats." : "No chats yet.<br>Open <b>People</b> or search a name to start your first conversation.";
    box.innerHTML = `<div class="empty-note"><div class="ic">💬</div><p>${msg}</p></div>`;
    return;
  }
  const anim = !listAnimated; listAnimated = true;
  box.innerHTML = items.map((it, i) => {
    const d = it.data, n = d.unread?.[S.uid] || 0, mine = d.lastSenderId === S.uid;
    const u = it.user, on = !it.isGroup && isOnline(u);
    const who = it.isGroup ? (mine ? "You: " : (d.lastSenderName ? d.lastSenderName.split(" ")[0] + ": " : "")) : (mine ? "You: " : "");
    const isP = pinned.includes(it.id), isM = muted.has(it.id);
    const active = S.chatId === it.id;
    return `<button class="chat-item ${active ? "active" : ""} ${n ? "unread" : ""}" data-chat="${it.id}" style="${anim ? `animation-delay:${Math.min(i, 10) * 35}ms` : "animation:none"}">
      <div class="av-wrap">${avatar(itemAv(it), 52)}${on ? '<i class="dot"></i>' : ""}</div>
      <div class="ci-main">
        <div class="ci-top"><b>${it.isGroup ? esc(itemTitle(it)) : nameHtml(u)}</b><time>${listTime(ms(d.updatedAt))}</time></div>
        <div class="ci-bot"><span class="ci-prev">${mine && d.lastMessage && !it.isGroup ? icon("check", 14) : ""}<span>${who}${esc(d.lastMessage || "")}</span></span>
          <span class="ci-icons">${isM ? icon("bell-off", 14) : ""}${isP ? icon("pin", 14) : ""}${n ? `<span class="badge ${isM ? "mute" : ""}">${n > 99 ? "99+" : n}</span>` : ""}</span></div>
      </div></button>`;
  }).join("");
}

/* chat list context menu (right click / long press) */
function chatItemMenu(chatId, x, y) {
  const it = S.chatItems.find(i => i.id === chatId); if (!it) return;
  const isP = myList("pinned").includes(chatId), isM = myList("muted").includes(chatId), isA = myList("archived").includes(chatId);
  const menu = $("#msgMenu");
  menu.innerHTML = `<button class="mm-item" data-ca="pinned">${icon("pin", 18)} ${isP ? "Unpin" : "Pin"} chat</button>
    <button class="mm-item" data-ca="muted">${icon(isM ? "bell" : "bell-off", 18)} ${isM ? "Unmute" : "Mute"}</button>
    <button class="mm-item" data-ca="archived">${icon("archive", 18)} ${isA ? "Unarchive" : "Archive"}</button>`;
  menu.dataset.chat = chatId; delete menu.dataset.id;
  placeMenu(x, y);
}
async function chatAction(act, chatId) {
  const list = myList(act), has = list.includes(chatId);
  if (act === "pinned" && !has && list.length >= 3) return toast("You can pin up to 3 chats");
  await updateDoc(userRef(), { [act]: has ? arrayRemove(chatId) : arrayUnion(chatId) }).catch(() => toast("Action failed", "err"));
  toast(({ pinned: has ? "Unpinned" : "Pinned", muted: has ? "Unmuted" : "Muted", archived: has ? "Moved to chats" : "Archived" })[act]);
}

/* =====================  SEARCH (list)  ===================== */
let searchSeq = 0;
export async function onSearchInput(text) {
  const raw = text.trim();
  $("#searchClear").classList.toggle("hidden", !raw);
  const box = $("#searchResults");
  if (!raw) { box.classList.add("hidden"); $("#chatList").classList.remove("hidden"); $("#chatFilters").classList.remove("hidden"); return; }
  const q = raw.toLowerCase().replace(/^@/, "");
  $("#chatList").classList.add("hidden"); $("#chatFilters").classList.add("hidden");
  box.classList.remove("hidden");
  const seq = ++searchSeq;
  const chats = S.chatItems.filter(it => itemTitle(it).toLowerCase().includes(q) || (it.user?.usernameLower || "").includes(q));
  let html = chats.length ? `<div class="section-title">Chats</div>` + chats.map(it => `<button class="chat-item" data-chat="${it.id}" style="animation:none"><div class="av-wrap">${avatar(itemAv(it), 46)}</div><div class="ci-main"><div class="ci-top"><b>${esc(itemTitle(it))}</b></div><div class="ci-prev">${it.isGroup ? "Group" : "@" + esc(it.user?.username || "")}</div></div></button>`).join("") : "";
  box.innerHTML = html + '<div class="section-title">People</div><div class="skeleton"></div><div class="skeleton"></div>';
  try {
    const { searchPeople, personCard } = await import("./people.js");
    const people = await searchPeople(raw);
    if (seq !== searchSeq) return;
    const mine = new Set(S.me.contacts || []);
    box.innerHTML = html + '<div class="section-title">People</div>' + (people.length
      ? people.map(u => personCard(u, `${mine.has(u.id) ? '<span class="tag">Contact</span>' : ""}${u.area ? `<span class="tag area">${esc(u.area)}</span>` : ""}`)).join("")
      : `<div class="empty-note">No people found for "${esc(raw)}".<br>Try a different name or username.</div>`);
  } catch (e) {
    console.error(e);
    if (seq === searchSeq) box.innerHTML = html + `<div class="empty-note">Search failed. Please try again.</div>`;
  }
}
export function clearSearch() {
  $("#searchInput").value = ""; onSearchInput("");
}

/* =====================  OPEN / CLOSE CHAT  ===================== */
let peerUnsub = null, chatUnsub = null, msgUnsub = null;
let prevLastRead = "", typingCheck = null, firstRender = true, firstMsgSnap = true, stick = true, newBelow = 0;
let searchTerm = "";
const rendered = new Set();

export const openChat = peerId => openConversation({ peerId });

export async function openConversation({ peerId, chatId, isGroup: forceGroup }) {
  if (peerId && peerId === S.uid) return;
  const cid = chatId || (peerId ? chatIdOf(S.uid, peerId) : null);
  if (!cid) return;
  if (S.chatId === cid) { showChatView(); return; }
  closeChat(true);
  const known = S.chatItems.find(i => i.id === cid);
  const isGroup = chatId ? (forceGroup ?? !!known?.isGroup) : false;
  let peer = null;
  if (!isGroup) {
    const pid = peerId || known?.otherId;
    peer = await getUser(pid, 0);
    if (!peer) return toast("User not found", "err");
    S.peerId = pid; S.peer = peer;
  } else { S.peerId = null; S.peer = null; }
  S.chatId = cid; S.isGroup = isGroup;
  S.chatExists = S.knownChats.has(cid); S.chatDoc = known?.data || null; S.msgs = []; S.msgLimit = 150;
  S.members = new Map(); if (S.me) S.members.set(S.uid, S.me); if (peer) S.members.set(peer.id, peer);
  firstRender = true; firstMsgSnap = true; prevLastRead = ""; newBelow = 0; rendered.clear(); closeChatSearch();
  renderHeader(); renderComposerState(); renderMessages(); restoreDraft();
  showChatView();
  if (!isCoarse()) $("#msgInput").focus({ preventScroll: true });
  renderChatList();

  if (!isGroup) {
    peerUnsub = onSnapshot(doc(db, "users", S.peerId), s => {
      if (!s.exists()) return;
      S.peer = cacheUser({ id: s.id, ...s.data() }); S.members.set(s.id, S.peer);
      renderStatus(); renderComposerState();
    });
  }
  chatUnsub = onSnapshot(doc(db, "chats", cid), s => {
    S.chatExists = s.exists(); S.chatDoc = s.exists() ? s.data() : null;
    if (s.exists()) {
      S.knownChats.add(cid);
      if (S.isGroup && !(S.chatDoc.participants || []).includes(S.uid)) { toast("You are no longer in this group"); closeChat(); return; }
      if (!msgUnsub) subscribeMessages();
      loadMembers();
      markRead();
      const lr = JSON.stringify(S.chatDoc.lastRead || {}, (k, v) => v?.toMillis ? v.toMillis() : v);
      if (lr !== prevLastRead) { prevLastRead = lr; renderMessages(); }
    }
    renderHeader(); renderStatus(); renderPinned();
  }, e => { console.error("chat doc", e); if (e.code === "permission-denied" && S.isGroup) { toast("No access to this group", "err"); closeChat(); } });
}

async function loadMembers() {
  const ids = (S.chatDoc?.participants || []).filter(id => !S.members.has(id));
  if (!ids.length) return;
  const cid = S.chatId;
  const list = await Promise.all(ids.map(id => getUser(id, 300000)));
  if (cid !== S.chatId) return;
  list.forEach(u => u && S.members.set(u.id, u));
  renderMessages(); renderHeader();
}

function subscribeMessages() {
  const q = query(collection(db, "chats", S.chatId, "messages"), orderBy("createdAt", "asc"), limitToLast(S.msgLimit));
  msgUnsub = onSnapshot(q, snap => {
    S.msgs = snap.docs.map(d => ({ id: d.id, ...d.data(), _pending: d.metadata.hasPendingWrites }));
    if (!firstMsgSnap) snap.docChanges().forEach(c => {
      const d = c.doc.data();
      if (c.type === "added" && d.senderId !== S.uid && !c.doc.metadata.hasPendingWrites && d.type !== "call" && d.type !== "system") {
        beep("in"); if (!stick) newBelow++;
      }
    });
    firstMsgSnap = false;
    renderMessages();
    markRead();
  }, e => { console.error("messages", e); toast("Could not load messages", "err"); });
}
function resubscribe() { msgUnsub?.(); msgUnsub = null; subscribeMessages(); }

export function closeChat(keepView) {
  peerUnsub?.(); chatUnsub?.(); msgUnsub?.(); peerUnsub = chatUnsub = msgUnsub = null;
  clearTimeout(typingCheck); stopAudio();
  if (S.chatId && S.chatExists) updateDoc(doc(db, "chats", S.chatId), { [`typing.${S.uid}`]: 0 }).catch(() => {});
  S.peerId = null; S.peer = null; S.chatId = null; S.chatDoc = null; S.msgs = []; S.chatExists = false; S.isGroup = false; S.members = new Map();
  clearReply(); cancelRecording(true); closeChatSearch();
  $("#attachMenu").classList.add("hidden"); $("#emojiPanel").classList.add("hidden");
  if (!keepView) {
    $("#app").classList.remove("chat-open");
    $("#chatView").classList.add("hidden"); $("#emptyState").classList.remove("hidden");
    renderChatList();
  }
}
function showChatView() {
  $("#emptyState").classList.add("hidden"); $("#chatView").classList.remove("hidden");
  if (!$("#app").classList.contains("chat-open")) {
    $("#app").classList.add("chat-open");
    if (isMobile()) history.pushState({ chat: 1 }, "");
  }
}
export function goBack() { if (history.state?.chat) history.back(); else closeChat(); }

const memberName = uid => uid === S.uid ? "You" : (S.members.get(uid)?.displayName || "Someone");
function renderHeader() {
  if (!S.chatId) return;
  if (S.isGroup) {
    const d = S.chatDoc || {};
    $("#peerInfo").innerHTML = `<div class="av-wrap" id="peerAv">${avatar({ isGroup: true, displayName: d.name || "Group", photoURL: d.photoURL }, 42)}</div><div style="min-width:0"><b>${esc(d.name || "Group")}</b><small id="peerStatus"></small></div>`;
  } else {
    const p = S.peer;
    $("#peerInfo").innerHTML = `<div class="av-wrap" id="peerAv">${avatar(p, 42)}<i class="dot ${isOnline(p) ? "" : "hidden"}"></i></div><div style="min-width:0"><b>${nameHtml(p)}</b><small id="peerStatus"></small></div>`;
  }
  renderStatus();
}
function typingNames() {
  const t = S.chatDoc?.typing || {};
  return Object.entries(t).filter(([u, v]) => u !== S.uid && v && Date.now() - v < 4000).map(([u]) => u);
}
function renderStatus() {
  if (!S.chatId) return;
  const el = $("#peerStatus"); if (!el) return;
  const typers = typingNames(), typing = typers.length > 0;
  let text, on = false;
  if (typing) { text = S.isGroup ? `${memberName(typers[0]).split(" ")[0]}${typers.length > 1 ? " +" + (typers.length - 1) : ""} typing...` : "typing..."; on = true; }
  else if (S.isGroup) { const names = (S.chatDoc?.participants || []).map(memberName); text = `${names.length} members` + (names.length ? " · " + names.slice(0, 4).join(", ") + (names.length > 4 ? "..." : "") : ""); }
  else { text = presenceText(S.peer); on = isOnline(S.peer); }
  el.textContent = text; el.className = on ? "on" : "";
  $("#peerAv .dot")?.classList.toggle("hidden", !(on && !S.isGroup));
  $("#typingRow").classList.toggle("hidden", !typing);
  $("#typingName").textContent = typing ? (S.isGroup ? typers.map(u => memberName(u).split(" ")[0]).join(", ") : S.peer.displayName.split(" ")[0]) + " is typing" : "";
  clearTimeout(typingCheck);
  if (typing) {
    const t = Math.max(...typers.map(u => S.chatDoc.typing[u]));
    typingCheck = setTimeout(renderStatus, Math.max(300, 4100 - (Date.now() - t)));
  }
  if (typing && stick) { const b = $("#messages"); b.scrollTop = b.scrollHeight; }
}
function renderComposerState() {
  if (!S.chatId) return;
  let blockedMsg = "", iBlocked = false;
  if (!S.isGroup && S.peer) {
    iBlocked = !!S.me?.blocked?.includes(S.peerId);
    const theyBlocked = S.peer?.blocked?.includes(S.uid);
    if (iBlocked) blockedMsg = `<span>You blocked ${esc(S.peer.displayName)}.</span><button class="btn-secondary" id="unblockBtn">Unblock</button>`;
    else if (theyBlocked) blockedMsg = `<span>You can't send messages to this person.</span>`;
  }
  const bar = $("#blockedBar");
  $("#composerRow").classList.toggle("hidden", !!blockedMsg);
  bar.classList.toggle("hidden", !blockedMsg); bar.innerHTML = blockedMsg;
  $("#unblockBtn")?.addEventListener("click", () => toggleBlock(S.peerId));
  ["#voiceCallBtn", "#videoCallBtn"].forEach(s => $(s).classList.toggle("hidden", !!blockedMsg));
  $("#voiceCallBtn").title = S.isGroup ? "Start group voice call" : "Voice call";
  $("#videoCallBtn").title = S.isGroup ? "Start group video call" : "Video call";
}
function markRead() {
  const d = S.chatDoc;
  if (!d || document.visibilityState !== "visible") return;
  if ((d.unread?.[S.uid] || 0) > 0) {
    const upd = { [`unread.${S.uid}`]: 0 };
    if (S.me?.privacy?.readReceipts !== false) upd[`lastRead.${S.uid}`] = serverTimestamp();
    updateDoc(doc(db, "chats", S.chatId), upd).catch(() => {});
  }
}
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") markRead(); });

function renderPinned() {
  const p = S.chatDoc?.pinned, bar = $("#pinned");
  if (!p?.id) { bar.classList.add("hidden"); return; }
  bar.classList.remove("hidden");
  bar.innerHTML = `${icon("pin", 15)}<div style="flex:1;min-width:0"><b>Pinned message</b><div class="muted" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(p.text || "")}</div></div><button class="icon-btn small" data-unpin>${icon("x", 15)}</button>`;
}

/* =====================  RENDER MESSAGES  ===================== */
const hl = text => {
  if (!searchTerm) return linkify(text);
  const re = new RegExp(searchTerm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "ig");
  let out = "", last = 0, m;
  while ((m = re.exec(text))) {
    out += esc(text.slice(last, m.index)) + `<mark>${esc(m[0])}</mark>`; last = m.index + m[0].length;
    if (!m[0].length) re.lastIndex++;
  }
  return out + esc(text.slice(last));
};

function renderMessages() {
  const box = $("#messages");
  if (!S.chatId) { box.innerHTML = ""; return; }
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  const lastReadMap = {}; Object.entries(S.chatDoc?.lastRead || {}).forEach(([u, t]) => { lastReadMap[u] = ms(t); });
  const others = (S.chatDoc?.participants || [S.uid, S.peerId]).filter(u => u && u !== S.uid);
  const peerSeen = S.isGroup ? 0 : lastMs(S.peer);
  const list = S.msgs.filter(m => !(m.deletedFor || []).includes(S.uid));
  let html = "", prevDay = "", prevSender = null;
  if (S.msgs.length >= S.msgLimit) html += `<button class="chip-btn load-older" data-older>Load older messages</button>`;
  if (!list.length) html += `<div class="empty-chat"><div class="wave">👋</div><p>${S.isGroup ? "Say hi to the group" : `Say hi to <b>${esc(S.peer.displayName)}</b>`}</p><p class="tiny">Messages are only visible to ${S.isGroup ? "group members" : "the two of you"}.</p></div>`;
  list.forEach(m => {
    const t = ms(m.createdAt) || Date.now();
    const day = dayLabel(t);
    if (day !== prevDay) { html += `<div class="day"><span>${day}</span></div>`; prevDay = day; prevSender = null; }
    const special = m.type === "call" || m.type === "system";
    const first = prevSender !== m.senderId; prevSender = special ? null : m.senderId;
    html += messageHtml(m, first, t, lastReadMap, others, peerSeen);
  });
  box.innerHTML = html;
  const last = list[list.length - 1];
  const scroll = firstRender || nearBottom || (last && last.senderId === S.uid && !last._seenScroll);
  stick = scroll;
  if (scroll) {
    newBelow = 0;
    if (firstRender) { box.style.scrollBehavior = "auto"; box.scrollTop = box.scrollHeight; box.style.scrollBehavior = ""; }
    else box.scrollTop = box.scrollHeight;
  }
  updateToBottom();
  if (list.length) firstRender = false;
  list.forEach(m => rendered.add(m.id));
  restoreAudio();
}
function updateToBottom() {
  const box = $("#messages");
  const far = box.scrollHeight - box.scrollTop - box.clientHeight > 320;
  $("#toBottom").classList.toggle("hidden", !far);
  const n = $("#toBottomN"); n.textContent = newBelow; n.classList.toggle("hidden", !newBelow);
}

function senderLabel(m) {
  const u = S.members.get(m.senderId);
  const c = colorOf(m.senderId)[0];
  return `<div class="sender" style="color:${c}">${esc(u?.displayName || "Member")}${isOwnerUser(u) ? ownerBadge(13) : ""}</div>`;
}

function messageHtml(m, first, t, lastRead, others, peerSeen) {
  const mine = m.senderId === S.uid;
  if (m.type === "system") return `<div class="sys-msg">${esc(m.text || "")}</div>`;
  if (m.type === "call") {
    const ok = m.outcome === "completed";
    const label = ok ? `${m.callType === "video" ? "Video" : "Voice"} call · ${fmtDur(m.duration)}` : (m.outcome === "declined" ? "Call declined" : "Missed " + (m.callType === "video" ? "video" : "voice") + " call");
    return `<div class="call-msg ${ok ? "" : "missed"}">${icon(m.callType === "video" ? "video" : "phone", 16)}<span>${label}</span><span class="tiny">${timeShort(t)}</span></div>`;
  }
  let tick = "";
  if (mine) {
    const seen = S.isGroup ? (others.length > 0 && others.every(u => (lastRead[u] || 0) >= t - 1)) : (lastRead[S.peerId] || 0) >= t - 1;
    const delivered = !S.isGroup && peerSeen >= t - 1;
    tick = m._pending ? icon("clock", 12) : seen ? `<span class="seen">${icon("checks", 16)}</span>` : (delivered || (S.isGroup && S.chatDoc)) ? icon("checks", 16) : icon("check", 14);
  }
  const meta = `<div class="meta">${m.edited && !m.deleted ? "edited · " : ""}${timeShort(t)} ${tick}</div>`;
  const pop = rendered.has(m.id) ? "" : "pop";
  const wrapStart = `<div class="msg ${mine ? "mine" : "theirs"} ${first ? "first" : ""} ${pop}" data-id="${m.id}">`;
  const more = `<button class="m-more" data-more="${m.id}">${icon("chevron", 16)}</button>`;
  const sender = S.isGroup && !mine && first && !m.deleted ? senderLabel(m) : "";
  let body;
  if (m.deleted) {
    body = `<div class="bubble deleted">🚫 This message was deleted ${meta}</div>`;
  } else {
    const rq = m.replyTo;
    const quote = rq ? `<button class="quote" data-goto="${esc(rq.id)}"><b>${rq.senderId === S.uid ? "You" : esc(memberName(rq.senderId).split(" ")[0])}</b><span>${esc(rq.text || "")}</span></button>` : "";
    const fwd = m.fwd ? `<div class="fwd">${icon("forward", 12)} Forwarded</div>` : "";
    const url = safeUrl(m.url);
    if (m.type === "image" && url) body = `<div class="bubble media">${fwd}${quote}<img class="m-img" src="${esc(thumbUrl(url))}" loading="lazy" alt="photo" data-full="${esc(url)}">${m.text ? `<div class="cap">${hl(m.text)}</div>` : ""}${meta}</div>`;
    else if (m.type === "video" && url) body = `<div class="bubble media">${fwd}${quote}<video class="m-vid" controls preload="metadata" playsinline src="${esc(url)}"></video>${m.text ? `<div class="cap">${hl(m.text)}</div>` : ""}${meta}</div>`;
    else if (m.type === "audio" && url) {
      const wave = (m.wave && m.wave.length ? m.wave : Array.from({ length: 32 }, (_, i) => 20 + (i * 37 % 55)));
      body = `<div class="bubble">${fwd}${quote}<div class="aud" data-src="${esc(url)}" data-id="${m.id}" data-dur="${m.duration || 0}"><button class="aud-btn" data-aud>${icon("play", 18)}</button><div class="aud-bar" data-seek>${wave.map(v => `<i style="height:${Math.max(12, Math.min(100, v))}%"></i>`).join("")}</div><button class="aud-sp" data-speed>1x</button><span class="aud-t">${fmtDur(m.duration)}</span></div>${meta}</div>`;
    } else if (m.type === "file" && url) {
      const ext = fileExt(m.fileName);
      body = `<div class="bubble">${fwd}${quote}<a class="file-card" href="${esc(url)}" target="_blank" rel="noopener noreferrer" download="${esc(m.fileName || "file")}"><i class="fi" style="background:${docTone(ext)}">${icon("file", 18)}${esc((ext || "file").toUpperCase().slice(0, 4))}</i><span class="fx"><span class="fn">${esc(m.fileName || "File")}</span><span class="fs">${fmtSize(m.size)}${m.size ? " · " : ""}Tap to open</span></span><span class="fd">${icon("download", 18)}</span></a>${m.text ? `<div class="cap" style="padding:6px 2px 0">${hl(m.text)}</div>` : ""}${meta}</div>`;
    } else if (m.type === "location" && typeof m.lat === "number") {
      body = `<div class="bubble media">${fwd}${quote}<a class="loc-msg" href="${mapsLink(m.lat, m.lng)}" target="_blank" rel="noopener noreferrer">${mapHtml(m.lat, m.lng, 280, 150)}</a><div class="loc-label">${icon("pin", 15)}<span>${esc(m.label || "Shared location")}</span></div>${meta}</div>`;
    } else if (m.type === "poll") body = `<div class="bubble">${fwd}${pollHtml(m)}${meta}</div>`;
    else if (m.type === "meeting") {
      body = `<div class="bubble"><div class="meet-card"><span class="mi">${icon(m.kind === "voice" ? "phone" : "video", 22)}</span><div><b>${esc(m.title || "Meeting")}</b><small>${m.kind === "voice" ? "Group voice call" : "Group video call"} · tap to join</small></div><button class="jb" data-join="${esc(m.roomId)}" data-kind="${esc(m.kind || "video")}">Join</button></div>${meta}</div>`;
    } else body = `<div class="bubble">${fwd}${quote}${hl(m.text || "")}${meta}</div>`;
  }
  let reacts = "";
  if (m.reactions && !m.deleted) {
    const g = {};
    Object.entries(m.reactions).forEach(([u, e]) => { (g[e] = g[e] || []).push(u); });
    reacts = `<div class="reactions">${Object.entries(g).map(([e, us]) => `<button class="chip ${us.includes(S.uid) ? "me" : ""}" data-react="${m.id}" data-emoji="${e}">${e}${us.length > 1 ? `<small>${us.length}</small>` : ""}</button>`).join("")}</div>`;
  }
  return wrapStart + sender + body + reacts + (m.deleted ? "" : more) + "</div>";
}
// Cloudinary delivers smaller, optimised images when we ask for it.
function thumbUrl(u) {
  return /res\.cloudinary\.com\/.+\/image\/upload\//.test(u) && !/\/upload\/[^/]*(w_|f_|q_)/.test(u) ? u.replace("/image/upload/", "/image/upload/f_auto,q_auto,w_720/") : u;
}
function pollHtml(m) {
  const votes = m.votes || {}, total = Object.values(votes).filter(v => v?.length).length;
  const counts = {}; Object.values(votes).forEach(a => (a || []).forEach(id => { counts[id] = (counts[id] || 0) + 1; }));
  const mine = votes[S.uid] || [];
  return `<div class="poll"><h4>${icon("poll", 18)}<span>${esc(m.question || "Poll")}</span></h4>${(m.options || []).map(o => {
    const c = counts[o.id] || 0, pct = total ? Math.round(c / total * 100) : 0;
    return `<button class="po ${mine.includes(o.id) ? "me" : ""}" data-vote="${m.id}" data-opt="${o.id}"><i style="width:${pct}%"></i><span><span>${esc(o.text)}</span><b>${c}</b></span></button>`;
  }).join("")}<small>${total} vote${total === 1 ? "" : "s"}${m.multi ? " · multiple answers" : ""}</small></div>`;
}
async function votePoll(id, opt) {
  const m = S.msgs.find(z => z.id === id); if (!m) return;
  let cur = [...(m.votes?.[S.uid] || [])];
  if (m.multi) cur = cur.includes(opt) ? cur.filter(x => x !== opt) : [...cur, opt];
  else cur = cur.includes(opt) ? [] : [opt];
  await updateDoc(msgRef(id), { [`votes.${S.uid}`]: cur }).catch(() => toast("Could not vote", "err"));
}

/* =====================  SENDING  ===================== */
export async function sendToChat(chatId, payload, ctx = {}) {
  const known = S.chatItems.find(i => i.id === chatId);
  const isGroup = ctx.isGroup ?? (chatId === S.chatId ? S.isGroup : !!known?.isGroup);
  const participants = ctx.participants || (chatId === S.chatId ? S.chatDoc?.participants : null) || known?.data.participants;
  const peerId = ctx.peerId || (!isGroup ? (participants || []).find(p => p !== S.uid) : null);
  if (!isGroup && payload.type !== "call") {
    const peer = await getUser(peerId, 20000);
    if (peer?.blocked?.includes(S.uid)) { toast("You can't message this user", "err"); return false; }
    if (S.me.blocked?.includes(peerId)) { toast("Unblock this user to send messages", "err"); return false; }
  }
  const chatRef = doc(db, "chats", chatId), msgRef = doc(collection(chatRef, "messages"));
  const preview = previewOf(payload);
  const batch = writeBatch(db);
  const recips = isGroup ? (participants || []).filter(p => p !== S.uid) : [peerId];
  if (S.knownChats.has(chatId)) {
    const upd = { lastMessage: preview, lastSenderId: S.uid, updatedAt: serverTimestamp(), [`typing.${S.uid}`]: 0 };
    recips.forEach(r => { upd[`unread.${r}`] = increment(1); });
    if (isGroup) upd.lastSenderName = S.me.displayName;
    batch.update(chatRef, upd);
  } else {
    batch.set(chatRef, {
      participants: [S.uid, peerId].sort(), createdAt: serverTimestamp(), updatedAt: serverTimestamp(),
      lastMessage: preview, lastSenderId: S.uid, unread: { [peerId]: increment(1) }, typing: {}, lastRead: {}
    });
  }
  batch.set(msgRef, { senderId: S.uid, createdAt: serverTimestamp(), ...payload });
  try { await batch.commit(); } catch (e) { console.error(e); toast(e.code === "permission-denied" ? "Permission denied. Update Firestore rules (see README)." : "Message failed to send", "err", 5000); return false; }
  S.knownChats.add(chatId);
  if (!isGroup && !S.me.contacts?.includes(peerId)) updateDoc(userRef(), { contacts: arrayUnion(peerId) }).catch(() => {});
  return true;
}
export async function sendToPeer(peerId, payload) { return sendToChat(chatIdOf(S.uid, peerId), payload, { isGroup: false, peerId, participants: [S.uid, peerId] }); }
export function sendToCurrent(payload) {
  if (!S.chatId) return Promise.resolve(false);
  if (S.replyTo && !payload.replyTo && payload.type !== "system") { payload.replyTo = S.replyTo; clearReply(); }
  return sendToChat(S.chatId, payload, S.isGroup ? {} : { isGroup: false, peerId: S.peerId, participants: [S.uid, S.peerId] });
}

async function sendText() {
  const ta = $("#msgInput"), text = ta.value.trim();
  if (!text || !S.chatId) return;
  if (S.editing) {
    const m = S.editing; clearReply();
    ta.value = ""; autoGrow();
    if (text !== m.text) await updateDoc(doc(db, "chats", S.chatId, "messages", m.id), { text, edited: true }).catch(() => toast("Edit failed", "err"));
    return;
  }
  const payload = { type: "text", text };
  ta.value = ""; autoGrow(); toggleSendMic(); stopTyping();
  beep("send");
  await sendToCurrent(payload);
  try { localStorage.removeItem("kdraft-" + S.chatId); } catch { /* ignore */ }
}

function autoGrow() { const ta = $("#msgInput"); ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 140) + "px"; }
function toggleSendMic() { const has = $("#msgInput").value.trim().length > 0; $("#sendBtn").classList.toggle("hidden", !has); $("#micBtn").classList.toggle("hidden", has); }

let typingTimer = null, lastTypingSent = 0;
function onTyping() {
  if (!S.chatExists || !S.chatId) return;
  const now = Date.now(), ref = doc(db, "chats", S.chatId);
  if (now - lastTypingSent > 2000) { lastTypingSent = now; updateDoc(ref, { [`typing.${S.uid}`]: now }).catch(() => {}); }
  clearTimeout(typingTimer);
  typingTimer = setTimeout(stopTyping, 2500);
}
function stopTyping() {
  clearTimeout(typingTimer); lastTypingSent = 0;
  if (S.chatExists && S.chatId) updateDoc(doc(db, "chats", S.chatId), { [`typing.${S.uid}`]: 0 }).catch(() => {});
}

function setReply(m) {
  S.editing = null;
  S.replyTo = { id: m.id, senderId: m.senderId, type: m.type, text: previewOf(m) || "Message" };
  $("#replyWho").textContent = "Replying to " + (m.senderId === S.uid ? "yourself" : memberName(m.senderId));
  $("#replyText").textContent = S.replyTo.text;
  $("#replyBar").classList.remove("hidden"); $("#msgInput").focus();
}
function setEdit(m) {
  S.replyTo = null; S.editing = m;
  $("#replyWho").textContent = "Editing message"; $("#replyText").textContent = m.text;
  $("#replyBar").classList.remove("hidden");
  const ta = $("#msgInput"); ta.value = m.text; autoGrow(); toggleSendMic(); ta.focus();
}
function clearReply() {
  if (S.editing) { $("#msgInput").value = ""; autoGrow(); toggleSendMic(); }
  S.replyTo = null; S.editing = null; $("#replyBar").classList.add("hidden");
}

/* =====================  VOICE RECORDING  ===================== */
let rec = null, recStream = null, recChunks = [], recStart = 0, recTick = null, recCancelled = false, recPeaks = [], recAn = null, recRaf = 0, recCtx = null;
async function startRecording() {
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) return toast("Voice recording is not supported on this browser", "err");
  try { recStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
  catch { return toast("Please allow microphone access", "err"); }
  const mime = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"].find(m => MediaRecorder.isTypeSupported(m)) || "";
  rec = new MediaRecorder(recStream, mime ? { mimeType: mime, audioBitsPerSecond: 48000 } : {});
  recChunks = []; recCancelled = false; recPeaks = [];
  rec.ondataavailable = e => e.data.size && recChunks.push(e.data);
  rec.start(250);
  recStart = Date.now(); haptic(20);
  $("#composerRow").classList.add("hidden"); $("#recBar").classList.remove("hidden");
  $("#recTime").textContent = "0:00";
  recTick = setInterval(() => { $("#recTime").textContent = fmtDur((Date.now() - recStart) / 1000); }, 250);
  try {
    recCtx = new (window.AudioContext || window.webkitAudioContext)();
    const src = recCtx.createMediaStreamSource(recStream); recAn = recCtx.createAnalyser(); recAn.fftSize = 256; src.connect(recAn);
    const buf = new Uint8Array(recAn.frequencyBinCount), cv = $("#recWave"), cx = cv.getContext("2d");
    let lastPeak = 0;
    const draw = () => {
      recRaf = requestAnimationFrame(draw);
      recAn.getByteTimeDomainData(buf);
      let mx = 0; for (const v of buf) mx = Math.max(mx, Math.abs(v - 128));
      const lvl = Math.min(100, Math.round(mx / 128 * 130));
      if (Date.now() - lastPeak > 100) { recPeaks.push(lvl); lastPeak = Date.now(); }
      cx.clearRect(0, 0, cv.width, cv.height); cx.fillStyle = getComputedStyle(cv).color;
      const show = recPeaks.slice(-26);
      show.forEach((p, i) => { const h = Math.max(3, p / 100 * cv.height); cx.fillRect(i * 6, (cv.height - h) / 2, 3, h); });
    };
    draw();
  } catch { /* waveform optional */ }
}
function cancelRecording(silent) {
  if (!rec) return;
  recCancelled = true;
  try { rec.stop(); } catch { /* ignore */ }
  cleanupRec();
  if (!silent) renderComposerState();
}
function cleanupRec() {
  clearInterval(recTick); cancelAnimationFrame(recRaf);
  try { recCtx?.close(); } catch { /* ignore */ } recCtx = null;
  recStream?.getTracks().forEach(t => t.stop()); recStream = null;
  $("#recBar").classList.add("hidden"); $("#composerRow").classList.remove("hidden");
  rec = null;
}
function finishRecording() {
  if (!rec) return;
  const r = rec, dur = (Date.now() - recStart) / 1000, peaks = recPeaks.slice();
  r.onstop = async () => {
    if (recCancelled || dur < .7) return;
    const type = r.mimeType || "audio/webm";
    const ext = type.includes("mp4") ? "m4a" : "webm";
    const file = new File([new Blob(recChunks, { type })], `voice-${Date.now()}.${ext}`, { type });
    try {
      const up = await uploadFile(file, "voice message");
      const bars = 32, wave = [];
      for (let i = 0; i < bars; i++) { const a = Math.floor(i * peaks.length / bars), b = Math.max(a + 1, Math.floor((i + 1) * peaks.length / bars)); wave.push(Math.max(...peaks.slice(a, b), 8)); }
      await sendToCurrent({ type: "audio", url: up.secure_url, duration: Math.round(dur), fileName: file.name, wave });
    } catch (e) { toast(e.message || "Voice message failed", "err"); }
  };
  try { r.stop(); } catch { /* ignore */ }
  cleanupRec(); renderComposerState();
}

/* =====================  AUDIO PLAYER  ===================== */
const audio = new Audio();
let audioId = null, audioRate = 1;
function stopAudio() { audio.pause(); audio.removeAttribute("src"); audioId = null; }
function paintAudio(el, ratio) {
  const bars = el.querySelectorAll(".aud-bar i"); const n = Math.round(ratio * bars.length);
  bars.forEach((b, i) => b.classList.toggle("p", i < n));
}
audio.addEventListener("timeupdate", () => {
  const el = audioId && $(`.aud[data-id="${audioId}"]`); if (!el) return;
  if (audio.duration) paintAudio(el, audio.currentTime / audio.duration);
  el.querySelector(".aud-t").textContent = fmtDur(audio.currentTime);
});
audio.addEventListener("ended", () => {
  const el = audioId && $(`.aud[data-id="${audioId}"]`);
  if (el) { el.querySelector("[data-aud]").innerHTML = icon("play", 18); paintAudio(el, 0); el.querySelector(".aud-t").textContent = fmtDur(+el.dataset.dur); }
  audioId = null;
});
function toggleAudio(el) {
  const id = el.dataset.id;
  if (audioId === id && !audio.paused) { audio.pause(); el.querySelector("[data-aud]").innerHTML = icon("play", 18); return; }
  if (audioId !== id) {
    $$(".aud [data-aud]").forEach(b => { b.innerHTML = icon("play", 18); });
    audio.src = el.dataset.src; audioId = id;
  }
  audio.playbackRate = audioRate;
  audio.play().then(() => { el.querySelector("[data-aud]").innerHTML = icon("pause", 18); }).catch(() => toast("Could not play this audio", "err"));
}
function restoreAudio() {
  if (!audioId) return;
  const el = $(`.aud[data-id="${audioId}"]`); if (!el) return;
  el.querySelector("[data-aud]").innerHTML = icon(audio.paused ? "play" : "pause", 18);
  if (audio.duration) paintAudio(el, audio.currentTime / audio.duration);
  el.querySelector("[data-speed]").textContent = audioRate + "x";
}

/* =====================  MESSAGE MENU & ACTIONS  ===================== */
const msgRef = id => doc(db, "chats", S.chatId, "messages", id);
function placeMenu(x, y) {
  const menu = $("#msgMenu");
  menu.classList.remove("hidden");
  const w = menu.offsetWidth, h = menu.offsetHeight;
  menu.style.left = Math.max(8, Math.min(x, innerWidth - w - 8)) + "px";
  menu.style.top = Math.max(8, Math.min(y, innerHeight - h - 8)) + "px";
}
export function closeMenu() { $("#msgMenu").classList.add("hidden"); }
function openMsgMenu(id, x, y) {
  const m = S.msgs.find(z => z.id === id); if (!m || m.deleted) return;
  const mine = m.senderId === S.uid;
  const menu = $("#msgMenu");
  const copyable = m.type === "text" || m.type === "image" && m.text;
  menu.innerHTML = `<div class="mm-react">${QUICK_REACTIONS.map(e => `<button data-mr="${e}">${e}</button>`).join("")}</div>
    <button class="mm-item" data-ma="reply">${icon("reply", 18)} Reply</button>
    ${copyable ? `<button class="mm-item" data-ma="copy">${icon("copy", 18)} Copy</button>` : ""}
    <button class="mm-item" data-ma="forward">${icon("forward", 18)} Forward</button>
    ${m.type === "text" || m.type === "image" || m.type === "video" || m.type === "file" ? `<button class="mm-item" data-ma="pin">${icon("pin", 18)} Pin message</button>` : ""}
    ${mine && m.type === "text" ? `<button class="mm-item" data-ma="edit">${icon("pencil", 18)} Edit</button>` : ""}
    <button class="mm-item" data-ma="delme">${icon("trash", 18)} Delete for me</button>
    ${mine ? `<button class="mm-item danger" data-ma="delall">${icon("trash", 18)} Delete for everyone</button>` : ""}`;
  menu.dataset.id = id; delete menu.dataset.chat;
  placeMenu(x, y);
}
async function toggleReaction(id, emoji) {
  const m = S.msgs.find(z => z.id === id); if (!m) return;
  const cur = m.reactions?.[S.uid];
  haptic(8);
  await updateDoc(msgRef(id), { [`reactions.${S.uid}`]: cur === emoji ? deleteField() : emoji }).catch(() => toast("Could not react", "err"));
}
async function msgAction(act, id) {
  const m = S.msgs.find(z => z.id === id); if (!m) return;
  if (act === "reply") setReply(m);
  else if (act === "copy") { toast(await copyText(m.text || "") ? "Copied" : "Copy failed"); }
  else if (act === "edit") setEdit(m);
  else if (act === "forward") forwardModal(m);
  else if (act === "pin") { await updateDoc(doc(db, "chats", S.chatId), { pinned: { id: m.id, text: previewOf(m) || "Message", by: S.uid } }).then(() => toast("Message pinned")).catch(() => toast("Could not pin", "err")); }
  else if (act === "delme") await updateDoc(msgRef(id), { deletedFor: arrayUnion(S.uid) }).catch(() => toast("Delete failed", "err"));
  else if (act === "delall") await updateDoc(msgRef(id), { deleted: true, text: "", url: "", fileName: "", reactions: deleteField(), lat: deleteField(), lng: deleteField(), options: deleteField(), votes: deleteField() }).catch(() => toast("Delete failed", "err"));
}

/* forward */
function forwardModal(m) {
  const items = S.chatItems.filter(it => it.isGroup || it.user).sort((a, b) => ms(b.data.updatedAt) - ms(a.data.updatedAt));
  const sel = new Set();
  openModal(`<div class="mc-head"><h3>Forward to...</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div class="pick-list">${items.map(it => `<button class="pick" data-pk="${it.id}">${avatar(itemAv(it), 40)}<span class="pn">${esc(itemTitle(it))}<small>${it.isGroup ? "Group" : "@" + esc(it.user.username || "")}</small></span><i class="ck">${icon("check", 13)}</i></button>`).join("") || '<div class="empty-note">No chats yet</div>'}</div>
    <button class="btn-primary" id="fwdSend" disabled>Forward</button>`);
  const c = $("#modalCard");
  c.onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    const pk = e.target.closest("[data-pk]");
    if (pk) { const id = pk.dataset.pk; sel.has(id) ? sel.delete(id) : sel.add(id); pk.classList.toggle("on", sel.has(id)); $("#fwdSend").disabled = !sel.size; $("#fwdSend").textContent = sel.size ? `Forward to ${sel.size}` : "Forward"; return; }
    if (e.target.closest("#fwdSend")) {
      const { id, senderId, createdAt, reactions, replyTo, deleted, deletedFor, edited, _pending, ...rest } = m;
      rest.fwd = true;
      closeModal();
      for (const cid of sel) await sendToChat(cid, { ...rest });
      toast(`Forwarded to ${sel.size} chat${sel.size > 1 ? "s" : ""}`, "ok");
    }
  };
}

/* =====================  PROFILE / BLOCK / REPORT  ===================== */
export async function toggleBlock(uid) {
  const blocked = S.me.blocked?.includes(uid);
  await updateDoc(userRef(), { blocked: blocked ? arrayRemove(uid) : arrayUnion(uid) }).catch(() => toast("Action failed", "err"));
  toast(blocked ? "User unblocked" : "User blocked");
  closeModal(); closeMenu();
}
export async function showProfile(uid) {
  if (uid === S.uid) { const { showMyProfile } = await import("./settings.js"); return showMyProfile(); }
  const u = await getUser(uid, 0); if (!u) return;
  const isBlocked = S.me.blocked?.includes(uid);
  const me = S.me.geo, he = u.geo && u.privacy?.showLocation !== false ? u.geo : null;
  const dist = me && he ? fmtDistance(distanceKm(me, he)) : "";
  openModal(`${avatar(u, 100)}<h3>${nameHtml(u)}</h3>
    <p class="center muted">@${esc(u.username)}</p>
    <p class="center">${esc(u.bio || "")}</p>
    <p class="center muted tiny">${u.area ? "📍 " + esc(u.locality ? u.locality + ", " : "") + esc(u.area) + (dist ? " · " + dist : "") : ""}<br>${esc(presenceText(u))}</p>
    ${he ? `<a class="prof-map" href="${mapsLink(he.lat, he.lng)}" target="_blank" rel="noopener">${mapHtml(he.lat, he.lng, 300, 130, 16)}</a>` : ""}
    ${isOwnerUser(u) ? `<div class="owner-proof"><b>${ownerBadge(16)} Verified owner</b>Owner &amp; developer of Mupe</div>` : ""}
    <div class="row">${S.peerId === uid ? "" : `<button class="btn-primary" data-pm="chat">Message</button>`}<button class="btn-secondary" data-pm="close">Close</button></div>
    <div class="row"><button class="btn-secondary" data-pm="voice">${icon("phone", 16)} Voice</button><button class="btn-secondary" data-pm="video">${icon("video", 16)} Video</button></div>
    <div class="row"><button class="btn-danger" data-pm="block">${isBlocked ? "Unblock" : "Block"}</button><button class="btn-danger" data-pm="report">Report</button></div>`);
  $("#modalCard").onclick = async e => {
    const a = e.target.closest("[data-pm]")?.dataset.pm; if (!a) return;
    if (a === "close") closeModal();
    else if (a === "chat") { closeModal(); openChat(uid); }
    else if (a === "voice" || a === "video") { closeModal(); startCall(u, a); }
    else if (a === "block") toggleBlock(uid);
    else if (a === "report") reportUser(u);
  };
}
export function reportUser(u) {
  openModal(`<h3>Report ${esc(u.displayName)}</h3><p class="muted center tiny">Tell us what is wrong. Reports are reviewed by the Mupe team.</p>
    <textarea id="repReason" rows="4" maxlength="400" placeholder="Reason"></textarea>
    <div class="row"><button class="btn-secondary" data-pm="close">Cancel</button><button class="btn-primary" data-pm="send">Send report</button></div>`);
  $("#modalCard").onclick = async e => {
    const a = e.target.closest("[data-pm]")?.dataset.pm; if (!a) return;
    if (a === "close") return closeModal();
    const reason = $("#repReason").value.trim(); if (!reason) return toast("Please write a reason", "err");
    await addDoc(collection(db, "reports"), { reporterId: S.uid, reportedId: u.id, reason, createdAt: serverTimestamp() }).then(() => toast("Report sent. Thank you.")).catch(() => toast("Could not send report", "err"));
    closeModal();
  };
}
function openPeerMenu(btn) {
  const menu = $("#msgMenu");
  const isM = myList("muted").includes(S.chatId), isP = myList("pinned").includes(S.chatId);
  if (S.isGroup) {
    menu.innerHTML = `<button class="mm-item" data-pa="ginfo">${icon("info", 18)} Group info</button>
      <button class="mm-item" data-pa="search">${icon("search", 18)} Search</button>
      <button class="mm-item" data-pa="mute">${icon(isM ? "bell" : "bell-off", 18)} ${isM ? "Unmute" : "Mute"}</button>
      <button class="mm-item" data-pa="pin">${icon("pin", 18)} ${isP ? "Unpin" : "Pin"} chat</button>`;
  } else {
    const iB = S.me.blocked?.includes(S.peerId);
    menu.innerHTML = `<button class="mm-item" data-pa="profile">${icon("user", 18)} View profile</button>
      <button class="mm-item" data-pa="search">${icon("search", 18)} Search</button>
      <button class="mm-item" data-pa="mute">${icon(isM ? "bell" : "bell-off", 18)} ${isM ? "Unmute" : "Mute"}</button>
      <button class="mm-item" data-pa="pin">${icon("pin", 18)} ${isP ? "Unpin" : "Pin"} chat</button>
      <button class="mm-item" data-pa="meet">${icon("users", 18)} Start meeting</button>
      <button class="mm-item danger" data-pa="block">${icon("ban", 18)} ${iB ? "Unblock" : "Block"}</button>
      <button class="mm-item danger" data-pa="report">${icon("flag", 18)} Report</button>`;
  }
  delete menu.dataset.id; delete menu.dataset.chat;
  const r = btn.getBoundingClientRect();
  placeMenu(r.right - 210, r.bottom + 6);
}

/* in-chat search */
function openChatSearch() { $("#chatSearch").classList.remove("hidden"); $("#chatSearchInput").focus(); }
function closeChatSearch() { searchTerm = ""; $("#chatSearch").classList.add("hidden"); $("#chatSearchInput").value = ""; $("#chatSearchCount").textContent = ""; if (S.chatId) renderMessages(); }
let searchHits = [], searchPos = 0;
function runChatSearch(v) {
  searchTerm = v.trim();
  renderMessages();
  if (!searchTerm) { $("#chatSearchCount").textContent = ""; return; }
  const t = searchTerm.toLowerCase();
  searchHits = S.msgs.filter(m => !m.deleted && (m.text || m.fileName || "").toLowerCase().includes(t)).map(m => m.id);
  searchPos = searchHits.length - 1;
  $("#chatSearchCount").textContent = searchHits.length ? `${searchHits.length} found` : "No results";
  gotoMsg(searchHits[searchPos]);
}
function gotoMsg(id) {
  if (!id) return;
  const el = $("#messages").querySelector(`.msg[data-id="${CSS.escape(id)}"]`);
  if (el) { el.scrollIntoView({ block: "center", behavior: "smooth" }); el.classList.add("flash"); setTimeout(() => el.classList.remove("flash"), 1300); }
}

/* lightbox gallery */
let lbList = [], lbIdx = 0;
function openLightbox(url) {
  lbList = $$("#messages img.m-img").map(i => i.dataset.full);
  lbIdx = Math.max(0, lbList.indexOf(url)); showLb();
  $("#lightbox").classList.remove("hidden");
}
function showLb() {
  const u = lbList[lbIdx]; $("#lbImg").src = u; $("#lbDl").href = u;
  $("#lbTitle").textContent = `${lbIdx + 1} / ${lbList.length}`;
  $("#lbPrev").classList.toggle("hidden", lbIdx === 0); $("#lbNext").classList.toggle("hidden", lbIdx >= lbList.length - 1);
}

/* =====================  UI WIRING  ===================== */
export function initChatUI() {
  const input = $("#msgInput");
  const coarse = isCoarse();
  input.addEventListener("input", () => {
    autoGrow(); toggleSendMic(); onTyping();
    try { if (S.chatId) { input.value ? localStorage.setItem("kdraft-" + S.chatId, input.value) : localStorage.removeItem("kdraft-" + S.chatId); } } catch { /* ignore */ }
  });
  input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && !coarse && prefs().enterSend) { e.preventDefault(); sendText(); } });
  $("#sendBtn").onclick = sendText;
  $("#micBtn").onclick = startRecording;
  $("#recCancel").onclick = () => cancelRecording();
  $("#recSend").onclick = finishRecording;
  $("#replyClose").onclick = clearReply;
  $("#backBtn").onclick = goBack;
  $("#peerInfo").onclick = () => S.chatId && (S.isGroup ? showGroupInfo(S.chatId) : showProfile(S.peerId));
  $("#peerMenuBtn").onclick = e => { e.stopPropagation(); openPeerMenu(e.currentTarget); };
  $("#searchChatBtn").onclick = openChatSearch;
  $("#chatSearchClose").onclick = closeChatSearch;
  $("#chatSearchInput").addEventListener("input", e => runChatSearch(e.target.value));
  $("#chatSearchInput").addEventListener("keydown", e => { if (e.key === "Enter" && searchHits.length) { searchPos = (searchPos - 1 + searchHits.length) % searchHits.length; gotoMsg(searchHits[searchPos]); } });
  $("#voiceCallBtn").onclick = () => S.isGroup ? startMeetingFromChat("voice") : S.peer && startCall(S.peer, "voice");
  $("#videoCallBtn").onclick = () => S.isGroup ? startMeetingFromChat("video") : S.peer && startCall(S.peer, "video");
  $("#toBottom").onclick = () => { const b = $("#messages"); b.scrollTop = b.scrollHeight; newBelow = 0; updateToBottom(); };
  $("#pinned").addEventListener("click", e => { if (e.target.closest("[data-unpin]")) { updateDoc(doc(db, "chats", S.chatId), { pinned: deleteField() }).catch(() => {}); return; } gotoMsg(S.chatDoc?.pinned?.id); });

  initAttach();

  // emoji panel with categories
  const panel = $("#emojiPanel");
  const cats = Object.keys(EMOJI_GROUPS);
  const paintEmoji = c => { $("#emojiGrid").innerHTML = EMOJI_GROUPS[c].map(e => `<button type="button">${e}</button>`).join(""); $$("#emojiTabs button").forEach(b => b.classList.toggle("on", b.dataset.c === c)); };
  panel.innerHTML = `<div class="emoji-tabs" id="emojiTabs">${cats.map(c => `<button type="button" data-c="${c}">${c}</button>`).join("")}</div><div class="emoji-grid" id="emojiGrid"></div>`;
  paintEmoji(cats[0]);
  $("#emojiTabs").addEventListener("click", e => { const b = e.target.closest("button"); if (b) paintEmoji(b.dataset.c); });
  $("#emojiBtn").onclick = e => { e.stopPropagation(); $("#attachMenu").classList.add("hidden"); panel.classList.toggle("hidden"); };
  $("#emojiGrid").addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    const s = input.selectionStart ?? input.value.length;
    input.value = input.value.slice(0, s) + b.textContent + input.value.slice(input.selectionEnd ?? s);
    input.focus(); input.selectionStart = input.selectionEnd = s + b.textContent.length;
    autoGrow(); toggleSendMic(); onTyping();
  });

  // messages: delegated events
  const box = $("#messages");
  box.addEventListener("click", e => {
    const t = e.target;
    const more = t.closest("[data-more]"); if (more) { e.stopPropagation(); const r = more.getBoundingClientRect(); return openMsgMenu(more.dataset.more, r.left - 120, r.bottom + 4); }
    const chip = t.closest("[data-react]"); if (chip) return toggleReaction(chip.dataset.react, chip.dataset.emoji);
    const sp = t.closest("[data-speed]"); if (sp) { audioRate = audioRate === 1 ? 1.5 : audioRate === 1.5 ? 2 : 1; audio.playbackRate = audioRate; $$("[data-speed]").forEach(b => { b.textContent = audioRate + "x"; }); return; }
    const sk = t.closest("[data-seek]");
    if (sk && audioId === sk.closest(".aud").dataset.id && audio.duration) { const r = sk.getBoundingClientRect(); audio.currentTime = (e.clientX - r.left) / r.width * audio.duration; return; }
    const aud = t.closest("[data-aud]") || (sk && sk); if (aud) return toggleAudio(aud.closest(".aud"));
    const g = t.closest("[data-goto]"); if (g) return gotoMsg(g.dataset.goto);
    const v = t.closest("[data-vote]"); if (v) return votePoll(v.dataset.vote, v.dataset.opt);
    const j = t.closest("[data-join]"); if (j) return joinMeeting(j.dataset.join, { kind: j.dataset.kind });
    if (t.closest("[data-older]")) { S.msgLimit += 150; resubscribe(); return; }
    const img = t.closest("img.m-img"); if (img) openLightbox(img.dataset.full);
  });
  box.addEventListener("dblclick", e => { const m = e.target.closest(".msg"); if (m && !e.target.closest("a,button,video,.aud,img")) toggleReaction(m.dataset.id, "❤️"); });
  box.addEventListener("contextmenu", e => { const m = e.target.closest(".msg"); if (m) { e.preventDefault(); openMsgMenu(m.dataset.id, e.clientX, e.clientY); } });
  let lp = null, sx = 0, sy = 0, swEl = null, swDx = 0;
  box.addEventListener("touchstart", e => {
    const m = e.target.closest(".msg"); if (!m || e.target.closest("a,video,.aud")) return;
    const t = e.touches[0]; sx = t.clientX; sy = t.clientY; swEl = m; swDx = 0;
    lp = setTimeout(() => { swEl = null; haptic(15); openMsgMenu(m.dataset.id, t.clientX - 90, t.clientY - 40); }, 450);
  }, { passive: true });
  box.addEventListener("touchmove", e => {
    const t = e.touches[0], dx = t.clientX - sx, dy = t.clientY - sy;
    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) clearTimeout(lp);
    if (swEl && Math.abs(dy) < 24 && dx > 0) { swDx = Math.min(dx, 80); swEl.style.transform = `translateX(${swDx}px)`; }
  }, { passive: true });
  const endSwipe = () => {
    clearTimeout(lp);
    if (swEl) { swEl.style.transform = ""; if (swDx > 60) { const m = S.msgs.find(z => z.id === swEl.dataset.id); if (m && !m.deleted) { haptic(10); setReply(m); } } }
    swEl = null; swDx = 0;
  };
  ["touchend", "touchcancel"].forEach(ev => box.addEventListener(ev, endSwipe, { passive: true }));
  box.addEventListener("load", e => { if (e.target.tagName === "IMG" && stick) box.scrollTop = box.scrollHeight; }, true);
  box.addEventListener("scroll", () => { stick = box.scrollHeight - box.scrollTop - box.clientHeight < 140; if (stick) newBelow = 0; updateToBottom(); });

  // menu clicks
  $("#msgMenu").addEventListener("click", e => {
    const menu = $("#msgMenu"), id = menu.dataset.id, cid = menu.dataset.chat;
    const mr = e.target.closest("[data-mr]"), ma = e.target.closest("[data-ma]"), pa = e.target.closest("[data-pa]"), ca = e.target.closest("[data-ca]");
    if (mr && id) toggleReaction(id, mr.dataset.mr);
    else if (ma && id) msgAction(ma.dataset.ma, id);
    else if (ca && cid) chatAction(ca.dataset.ca, cid);
    else if (pa) {
      const a = pa.dataset.pa;
      if (a === "profile") showProfile(S.peerId); else if (a === "block") toggleBlock(S.peerId); else if (a === "report") reportUser(S.peer);
      else if (a === "ginfo") showGroupInfo(S.chatId); else if (a === "search") openChatSearch();
      else if (a === "mute") chatAction("muted", S.chatId); else if (a === "pin") chatAction("pinned", S.chatId);
      else if (a === "meet") startMeetingFromChat("video");
    }
    closeMenu();
  });
  document.addEventListener("click", e => {
    if (!e.target.closest("#msgMenu")) closeMenu();
    if (!e.target.closest("#emojiPanel") && !e.target.closest("#emojiBtn")) panel.classList.add("hidden");
    if (!e.target.closest("#attachMenu") && !e.target.closest("#attachBtn")) $("#attachMenu").classList.add("hidden");
  });
  $("#lightbox").addEventListener("click", e => {
    if (e.target.closest("#lbPrev")) { lbIdx = Math.max(0, lbIdx - 1); showLb(); return; }
    if (e.target.closest("#lbNext")) { lbIdx = Math.min(lbList.length - 1, lbIdx + 1); showLb(); return; }
    if (e.target.closest("#lbDl")) return;
    $("#lightbox").classList.add("hidden");
  });
  $("#modal").addEventListener("click", e => { if (e.target.id === "modal") closeModal(); });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { closeMenu(); closeModal(); $("#lightbox").classList.add("hidden"); panel.classList.add("hidden"); $("#attachMenu").classList.add("hidden"); if (!$("#chatSearch").classList.contains("hidden")) closeChatSearch(); }
    if (!$("#lightbox").classList.contains("hidden")) { if (e.key === "ArrowLeft") { lbIdx = Math.max(0, lbIdx - 1); showLb(); } if (e.key === "ArrowRight") { lbIdx = Math.min(lbList.length - 1, lbIdx + 1); showLb(); } }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); $("#searchInput").focus(); }
  });

  // lists
  const listClick = e => {
    const prof = e.target.closest("[data-profile]"); if (prof) { e.stopPropagation(); return showProfile(prof.dataset.profile); }
    const c = e.target.closest("[data-chat]"); if (c && c.classList.contains("chat-item")) return openConversation({ chatId: c.dataset.chat });
    const el = e.target.closest("[data-uid],[data-chat]"); if (!el) return;
    if (el.dataset.chat && !el.classList.contains("chat-item")) return openChat(el.dataset.chat);
    openChat(el.dataset.uid);
  };
  ["#chatList", "#discoverList", "#searchResults"].forEach(s => $(s).addEventListener("click", listClick));
  // chat list context menu
  let clp = null;
  const cl = $("#chatList");
  cl.addEventListener("contextmenu", e => { const c = e.target.closest(".chat-item"); if (c) { e.preventDefault(); chatItemMenu(c.dataset.chat, e.clientX, e.clientY); } });
  cl.addEventListener("touchstart", e => { const c = e.target.closest(".chat-item"); if (!c) return; const t = e.touches[0]; clp = setTimeout(() => { haptic(15); chatItemMenu(c.dataset.chat, t.clientX - 60, t.clientY - 20); }, 500); }, { passive: true });
  ["touchend", "touchmove", "touchcancel"].forEach(ev => cl.addEventListener(ev, () => clearTimeout(clp), { passive: true }));
  $("#chatFilters").addEventListener("click", e => { const b = e.target.closest("[data-f]"); if (b) setChatFilter(b.dataset.f); });
  $("#searchInput").addEventListener("input", e => debouncedSearch(e.target.value));
  $("#searchClear").onclick = clearSearch;
  $("#newGroupBtn").onclick = newGroupModal;
}
let _sT; const debouncedSearch = v => { clearTimeout(_sT); _sT = setTimeout(() => onSearchInput(v), 260); };

export function restoreDraft() {
  try { const d = localStorage.getItem("kdraft-" + S.chatId); if (d) { $("#msgInput").value = d; autoGrow(); toggleSendMic(); } } catch { /* ignore */ }
}
export function refreshMe() {
  if (S.chatId) { renderComposerState(); }
  renderChatList(); updateBadge();
}
export { renderMessages, itemTitle };
