// ====== Mupe configuration ======
export const firebaseConfig = {
  apiKey: "AIzaSyB1EHfr6QmOucAJQtQSa_gegfCpqcUrbbg",
  authDomain: "kotha-app-43d1f.firebaseapp.com",
  projectId: "kotha-app-43d1f",
  storageBucket: "kotha-app-43d1f.firebasestorage.app",
  messagingSenderId: "431550084152",
  appId: "1:431550084152:web:fb48c2a603e1627dd7e2cd"
};

// File / image / voice uploads (unsigned preset, no secret needed)
export const CLOUDINARY = { cloudName: "m2hyntkm", uploadPreset: "kotha_unsigned" };

// ---------- Owner / credit ----------
export const OWNER = {
  name: "Md. Fardin Fahim",
  email: "mdfardinfahim.me@gmail.com",
  // Optional: paste the owner's Firebase UID here (it is shown in Settings > About when the owner is logged in)
  // so that the verified-owner badge is visible to every user. Without it, the badge shows for the owner only.
  uids: [],
  credit: "A app by Md. Fardin Fahim",
  year: new Date().getFullYear()
};
export const APP_VERSION = "3.4.0";

// ---------- Calls ----------
// STUN is free. For calls to work on EVERY network (mobile data <-> WiFi, strict NAT) add a TURN server here
// (Cloudflare Realtime TURN, Metered.ca, Twilio, or your own coturn). Example:
// { urls: ["turn:YOUR-TURN-HOST:3478", "turns:YOUR-TURN-HOST:443?transport=tcp"], username: "USER", credential: "PASS" }
export const TURN_SERVERS = [
  { urls: ["turn:global.relay.metered.ca:80", "turn:global.relay.metered.ca:80?transport=tcp", "turn:global.relay.metered.ca:443", "turns:global.relay.metered.ca:443?transport=tcp"],
    username: "9e416615f20b2104b924faed", credential: "2iTsKDyULnCw0pW9" }
];
export const ICE_SERVERS = [
  { urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302", "stun:stun.cloudflare.com:3478"] },
  ...TURN_SERVERS
];

// Media quality (HD)
export const AUDIO_CONSTRAINTS = { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 };
export const VIDEO_CONSTRAINTS = { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } };
export const VIDEO_BITRATE = { hd: 2_200_000, sd: 700_000, low: 280_000 };
export const AUDIO_BITRATE = 40_000;
export const EXACT_ACC = 300; // GPS accuracy (metres) needed to show an exact location; worse than this = district only
export const STORY_MS = 24 * 3600 * 1000; // stories and notes disappear after 24 hours
export const MEET_MAX = 8; // max people in one mesh meeting (above ~8 browsers struggle)

// ---------- Uploads (Cloudinary free plan limits) ----------
export const MAX_MB = { image: 10, video: 90, audio: 20, file: 10 };
export const MAX_UPLOAD_MB = 10;

// ---------- Locations (Bangladesh) ----------
// [district, lat, lng]
export const DIVISIONS = {
  "Barishal": [["Barguna",22.15,90.12],["Barishal",22.70,90.37],["Bhola",22.69,90.65],["Jhalokathi",22.64,90.20],["Patuakhali",22.36,90.33],["Pirojpur",22.58,89.97]],
  "Chattogram": [["Bandarban",22.19,92.22],["Brahmanbaria",23.97,91.11],["Chandpur",23.23,90.67],["Chattogram",22.36,91.78],["Cumilla",23.46,91.18],["Cox's Bazar",21.45,91.97],["Feni",23.02,91.40],["Khagrachhari",23.12,91.98],["Lakshmipur",22.94,90.84],["Noakhali",22.82,91.10],["Rangamati",22.65,92.17]],
  "Dhaka": [["Dhaka",23.81,90.41],["Faridpur",23.60,89.84],["Gazipur",24.00,90.42],["Gopalganj",23.01,89.83],["Kishoreganj",24.44,90.78],["Madaripur",23.17,90.19],["Manikganj",23.86,90.00],["Munshiganj",23.54,90.53],["Narayanganj",23.62,90.50],["Narsingdi",23.92,90.72],["Rajbari",23.76,89.65],["Shariatpur",23.22,90.35],["Tangail",24.25,89.92]],
  "Khulna": [["Bagerhat",22.65,89.79],["Chuadanga",23.64,88.85],["Jashore",23.17,89.21],["Jhenaidah",23.54,89.17],["Khulna",22.82,89.55],["Kushtia",23.90,89.12],["Magura",23.49,89.42],["Meherpur",23.76,88.63],["Narail",23.17,89.50],["Satkhira",22.72,89.07]],
  "Mymensingh": [["Jamalpur",24.92,89.94],["Mymensingh",24.75,90.40],["Netrokona",24.87,90.73],["Sherpur",25.02,90.02]],
  "Rajshahi": [["Bogura",24.85,89.37],["Chapainawabganj",24.60,88.28],["Joypurhat",25.10,89.02],["Naogaon",24.80,88.94],["Natore",24.41,89.00],["Pabna",24.00,89.25],["Rajshahi",24.37,88.60],["Sirajganj",24.45,89.70]],
  "Rangpur": [["Dinajpur",25.63,88.64],["Gaibandha",25.33,89.53],["Kurigram",25.81,89.65],["Lalmonirhat",25.99,89.28],["Nilphamari",25.93,88.86],["Panchagarh",26.34,88.55],["Rangpur",25.75,89.25],["Thakurgaon",26.03,88.47]],
  "Sylhet": [["Habiganj",24.38,91.42],["Moulvibazar",24.48,91.77],["Sunamganj",25.07,91.40],["Sylhet",24.90,91.87]]
};
export const AREAS = [...Object.values(DIVISIONS).flat().map(d => d[0]).sort(), "Other"];

export const EMOJI_GROUPS = {
  "😀": "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 🤗 🤔 🤨 😐 😑 😶 🙄 😏 😴 😪 😮 😲 😢 😭 😤 😡 🤯 😱 😨 🥺 😎 🤩 🥳 🤭 🫡 🫠 😌 🤤 😵 🤒 🤕 🥶 🥵".split(" "),
  "👍": "👍 👎 👏 🙌 🙏 💪 👋 ✌️ 🤞 👌 🫶 🤝 ✊ 🤙 👊 🫰 🤟 🖐️ ☝️ 👈 👉 👆 👇 ✍️ 🤲 🫂".split(" "),
  "❤️": "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💖 💗 💘 💝 💞 💓 ❣️ 🔥 ✨ ⭐ 🌟 💫 🎉 🎊 🎁 🎂 💯 ✅ ❌ ❗ ❓".split(" "),
  "🌸": "🌹 🌸 🌼 🌻 🌺 ☀️ 🌙 ⭐ 🌈 ☁️ ⚡ ❄️ 🌊 🌴 🍀 🌿 🐶 🐱 🦁 🐯 🐼 🦋 🐝 🐢".split(" "),
  "🍕": "☕ 🍕 🍔 🍟 🍰 🍫 🍎 🍉 🍇 🥭 🍚 🍛 🍗 🍜 🥤 🍦 🍩 🍪 🍿".split(" "),
  "⚽": "⚽ 🏏 🏀 🎮 🎧 🎵 🎬 📷 📱 💻 🚗 ✈️ 🏠 📚 💡 🔔 🎯 🏆".split(" ")
};
export const EMOJIS = Object.values(EMOJI_GROUPS).flat();
export const QUICK_REACTIONS = ["❤️", "😂", "😮", "😢", "🙏", "👍"];

export const ACCENTS = {
  mupe:    { name: "Mupe",    a1: "#b4f52c", a2: "#8edb00" },
  indigo:  { name: "Indigo",  a1: "#4f46e5", a2: "#9333ea" },
  ocean:   { name: "Ocean",   a1: "#0284c7", a2: "#4f46e5" },
  emerald: { name: "Emerald", a1: "#059669", a2: "#0891b2" },
  rose:    { name: "Rose",    a1: "#e11d48", a2: "#c026d3" },
  sunset:  { name: "Sunset",  a1: "#f97316", a2: "#e11d48" },
  graphite:{ name: "Graphite",a1: "#334155", a2: "#0f172a" }
};
export const WALLPAPERS = { doodle: "Doodle", plain: "Plain", gradient: "Gradient", dots: "Dots" };
