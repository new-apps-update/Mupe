import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult,
  onAuthStateChanged, signOut, reauthenticateWithPopup, deleteUser,
  RecaptchaVerifier, signInWithPhoneNumber, reauthenticateWithPhoneNumber
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  initializeFirestore, persistentLocalCache, persistentMultipleTabManager,
  doc, getDoc, setDoc, updateDoc, deleteDoc, collection, query, where, orderBy,
  limit, limitToLast, onSnapshot, addDoc, serverTimestamp, writeBatch, arrayUnion, arrayRemove,
  increment, getDocs, deleteField, startAt, endAt, runTransaction
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig } from "./config.js";

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

let _db;
try {
  // Offline cache = chats open instantly (like WhatsApp) and work with a weak connection.
  _db = initializeFirestore(app, {
    experimentalAutoDetectLongPolling: true,
    ignoreUndefinedProperties: true,
    localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() })
  });
} catch (e) {
  console.warn("Persistent cache unavailable, using memory cache", e);
  _db = initializeFirestore(app, { experimentalAutoDetectLongPolling: true, ignoreUndefinedProperties: true });
}
export const db = _db;
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });

export {
  RecaptchaVerifier, signInWithPhoneNumber, reauthenticateWithPhoneNumber,
  signInWithPopup, signInWithRedirect, getRedirectResult, onAuthStateChanged, signOut, reauthenticateWithPopup, deleteUser,
  doc, getDoc, setDoc, updateDoc, deleteDoc, collection, query, where, orderBy, limit, limitToLast,
  onSnapshot, addDoc, serverTimestamp, writeBatch, arrayUnion, arrayRemove, increment,
  getDocs, deleteField, startAt, endAt, runTransaction
};
