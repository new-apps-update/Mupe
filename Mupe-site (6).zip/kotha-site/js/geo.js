import { DIVISIONS } from "./config.js";

const B32 = "0123456789bcdefghjkmnpqrstuvwxyz";

export function geohashEncode(lat, lng, precision = 6) {
  let idx = 0, bit = 0, even = true, hash = "";
  let latR = [-90, 90], lngR = [-180, 180];
  while (hash.length < precision) {
    const r = even ? lngR : latR, v = even ? lng : lat, mid = (r[0] + r[1]) / 2;
    if (v >= mid) { idx = idx * 2 + 1; r[0] = mid; } else { idx = idx * 2; r[1] = mid; }
    even = !even;
    if (++bit === 5) { hash += B32[idx]; bit = 0; idx = 0; }
  }
  return hash;
}
export function geohashDecode(hash) {
  let even = true, latR = [-90, 90], lngR = [-180, 180];
  for (const c of hash) {
    const cd = B32.indexOf(c);
    for (let m = 16; m > 0; m >>= 1) {
      const r = even ? lngR : latR, mid = (r[0] + r[1]) / 2;
      if (cd & m) r[0] = mid; else r[1] = mid;
      even = !even;
    }
  }
  return { lat: (latR[0] + latR[1]) / 2, lng: (lngR[0] + lngR[1]) / 2, latErr: (latR[1] - latR[0]) / 2, lngErr: (lngR[1] - lngR[0]) / 2 };
}
// the cell containing (lat,lng) and its 8 neighbours at the given precision
export function geohashCells(lat, lng, precision = 4) {
  const h = geohashEncode(lat, lng, precision), c = geohashDecode(h);
  const out = new Set();
  for (const dy of [-1, 0, 1]) for (const dx of [-1, 0, 1]) {
    const la = c.lat + dy * c.latErr * 2, ln = c.lng + dx * c.lngErr * 2;
    if (la > -90 && la < 90) out.add(geohashEncode(la, ((ln + 540) % 360) - 180, precision));
  }
  return [...out];
}

export function distanceKm(a, b) {
  const R = 6371, rad = x => x * Math.PI / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
export function fmtDistance(km) {
  if (km == null || isNaN(km)) return "";
  const m = km * 1000;
  if (m < 20) return "Right here";
  if (m < 1000) return Math.round(m / 10) * 10 + " m away";
  if (km < 10) return km.toFixed(1) + " km away";
  return Math.round(km) + " km away";
}

export const divisionOf = district => {
  for (const [div, list] of Object.entries(DIVISIONS)) if (list.some(d => d[0] === district)) return div;
  return "";
};
export const nearestDistrict = (lat, lng) => {
  let best = null, bd = 1e9;
  for (const [div, list] of Object.entries(DIVISIONS)) for (const [name, la, ln] of list) {
    const d = distanceKm({ lat, lng }, { lat: la, lng: ln });
    if (d < bd) { bd = d; best = { district: name, division: div, km: d }; }
  }
  return best;
};

function getOnce(timeout, maxAge) {
  return new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error("Location is not supported on this device"));
    navigator.geolocation.getCurrentPosition(
      p => res({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy }),
      e => rej(new Error(e.code === 1 ? "Location permission was denied" : "Could not get your location")),
      { enableHighAccuracy: true, timeout, maximumAge: maxAge });
  });
}
// Returns the best GPS fix we can get. If the first fix is coarse we try once more for a sharper one.
export async function getPosition(timeout = 12000) {
  const first = await getOnce(timeout, 0);
  if (first.acc <= 150) return first;
  try { const second = await getOnce(10000, 0); return second.acc < first.acc ? second : first; } catch { return first; }
}

// OpenStreetMap Nominatim reverse geocode (free, light use) with district fallback.
export async function reverseGeocode(lat, lng) {
  const fb = nearestDistrict(lat, lng);
  const near = fb && fb.km < 120;
  const out = { district: near ? fb.district : "", division: near ? fb.division : "", locality: "" };
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 5000);
    const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=17&addressdetails=1&accept-language=en&lat=${lat}&lon=${lng}`, { signal: ctl.signal });
    clearTimeout(t);
    const j = await r.json(), a = j.address || {};
    out.locality = a.neighbourhood || a.suburb || a.hamlet || a.village || a.quarter || a.town || a.city_district || a.city || a.county || "";
    out.label = j.display_name || "";
    const dist = (a.state_district || a.county || a.city || "").replace(/ (District|Zila|Division)$/i, "");
    const all = Object.values(DIVISIONS).flat().map(d => d[0]);
    const hit = all.find(n => n.toLowerCase() === dist.toLowerCase()) || all.find(n => dist.toLowerCase().includes(n.toLowerCase()));
    if (hit) { out.district = hit; out.division = divisionOf(hit); }
  } catch { /* offline or blocked: keep fallback */ }
  if (!out.district) { out.district = "Other"; out.division = ""; }
  return out;
}

/* ---------- static map tiles (OpenStreetMap) ---------- */
export function tileInfo(lat, lng, z = 15) {
  const n = 2 ** z, x = (lng + 180) / 360 * n;
  const lr = lat * Math.PI / 180, y = (1 - Math.log(Math.tan(lr) + 1 / Math.cos(lr)) / Math.PI) / 2 * n;
  return { z, x, y, tx: Math.floor(x), ty: Math.floor(y), fx: x - Math.floor(x), fy: y - Math.floor(y) };
}
// 3x3 tile mosaic centred on the point; returns html of fixed size w x h
export function mapHtml(lat, lng, w = 280, h = 160, z = 15) {
  const t = tileInfo(lat, lng, z), S = 256;
  const left = w / 2 - (1 + t.fx) * S, top = h / 2 - (1 + t.fy) * S;
  let tiles = "";
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++)
    tiles += `<img loading="lazy" alt="" src="https://tile.openstreetmap.org/${z}/${t.tx + dx}/${t.ty + dy}.png" style="left:${left + (dx + 1) * S}px;top:${top + (dy + 1) * S}px">`;
  return `<div class="mapbox" style="width:${w}px;height:${h}px">${tiles}<span class="mappin"></span></div>`;
}
export const mapsLink = (lat, lng) => `https://www.google.com/maps?q=${lat},${lng}`;
