import { db, doc, setDoc, updateDoc, collection, serverTimestamp, arrayUnion, arrayRemove, onSnapshot } from "./firebase.js";
import { S } from "./state.js";
import { $, esc, avatar, icon, toast, openModal, closeModal, nameHtml } from "./utils.js";
import { getUser, sendToChat, openConversation } from "./chat.js";
import { uploadFile, compressImage } from "./attach.js";
import { startMeetingFromChat } from "./meet.js";

const MAX_MEMBERS = 256;

async function contactUsers() {
  const ids = [...new Set([...(S.me.contacts || []), ...S.chatItems.filter(i => !i.isGroup).map(i => i.otherId)])].filter(id => id && !(S.me.blocked || []).includes(id));
  const us = await Promise.all(ids.map(id => getUser(id, 300000)));
  return us.filter(Boolean).sort((a, b) => (a.displayName || "").localeCompare(b.displayName || ""));
}

const pickRow = (u, on) => `<button class="pick ${on ? "on" : ""}" data-pk="${u.id}">${avatar(u, 40)}<span class="pn">${nameHtml(u)}<small>@${esc(u.username || "")}${u.area ? " · " + esc(u.area) : ""}</small></span><i class="ck">${icon("check", 13)}</i></button>`;

export async function newGroupModal() {
  const contacts = await contactUsers();
  const sel = new Set(); let photo = "";
  openModal(`<div class="mc-head"><h3>New group</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div style="display:flex;align-items:center;gap:12px"><button class="send-btn" id="ngPhoto" style="width:60px;height:60px">${icon("camera", 24)}</button><input id="ngName" maxlength="40" placeholder="Group name" style="flex:1"></div>
    <input type="file" id="ngFile" accept="image/*" class="hidden">
    <label>Add members <span class="muted" id="ngCount">0 selected</span></label>
    <div class="pick-list" id="ngList">${contacts.length ? contacts.map(u => pickRow(u, false)).join("") : '<div class="empty-note">No contacts yet.<br>Start a chat with someone first, then add them here.</div>'}</div>
    <button class="btn-primary" id="ngCreate" disabled>Create group</button>`);
  const upd = () => { $("#ngCount").textContent = sel.size + " selected"; $("#ngCreate").disabled = !sel.size || $("#ngName").value.trim().length < 1; };
  $("#ngName").addEventListener("input", upd);
  $("#ngFile").onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    try { const up = await uploadFile(await compressImage(f, 512), "group photo"); photo = up.secure_url; $("#ngPhoto").innerHTML = `<img class="av" src="${esc(photo)}" style="width:60px;height:60px">`; } catch (er) { toast(er.message, "err"); }
  };
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    if (e.target.closest("#ngPhoto")) return $("#ngFile").click();
    const pk = e.target.closest("[data-pk]");
    if (pk) { const id = pk.dataset.pk; sel.has(id) ? sel.delete(id) : sel.add(id); pk.classList.toggle("on", sel.has(id)); upd(); return; }
    if (e.target.closest("#ngCreate")) {
      const name = $("#ngName").value.trim();
      const btn = $("#ngCreate"); btn.disabled = true;
      const ref = doc(collection(db, "chats")), id = ref.id;
      try {
        await setDoc(ref, {
          isGroup: true, name, photoURL: photo, participants: [S.uid, ...sel], admins: [S.uid], createdBy: S.uid,
          createdAt: serverTimestamp(), updatedAt: serverTimestamp(), lastMessage: "Group created", lastSenderId: S.uid, lastSenderName: S.me.displayName,
          unread: {}, typing: {}, lastRead: {}
        });
      } catch (er) {
        console.error(er); btn.disabled = false;
        return toast(er.code === "permission-denied" ? "Groups need the updated Firestore rules (see README, 1 minute step)" : "Could not create group", "err", 6000);
      }
      S.knownChats.add(id);
      closeModal();
      await sendToChat(id, { type: "system", text: `${S.me.displayName} created the group "${name}"` }, { isGroup: true, participants: [S.uid, ...sel] });
      toast("Group created", "ok");
      openConversation({ chatId: id, isGroup: true });
    }
  };
}

export async function showGroupInfo(chatId) {
  const it = S.chatItems.find(i => i.id === chatId);
  const render = async d => {
    const admins = d.admins || [], amAdmin = admins.includes(S.uid);
    const users = await Promise.all((d.participants || []).map(id => getUser(id, 120000)));
    openModal(`<div class="mc-head"><h3>Group info</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
      <div style="position:relative;align-self:center">${avatar({ isGroup: true, displayName: d.name, photoURL: d.photoURL }, 96)}${amAdmin ? `<button class="send-btn" id="giPhoto" style="position:absolute;right:-6px;bottom:-6px;width:34px;height:34px">${icon("camera", 16)}</button>` : ""}</div>
      <input type="file" id="giFile" accept="image/*" class="hidden">
      ${amAdmin ? `<div style="display:flex;gap:8px"><input id="giName" maxlength="40" value="${esc(d.name || "")}"><button class="btn-secondary" id="giSave">Save</button></div>` : `<h3>${esc(d.name || "")}</h3>`}
      <p class="muted center tiny">${(d.participants || []).length} members</p>
      <div class="row"><button class="btn-secondary" data-ga="video">${icon("video", 16)} Video</button><button class="btn-secondary" data-ga="voice">${icon("phone", 16)} Voice</button></div>
      ${amAdmin ? `<button class="btn-secondary" data-ga="add">${icon("user-plus", 16)} Add members</button>` : ""}
      <div class="pick-list" style="max-height:260px">${users.filter(Boolean).map(u => `<div class="pick" style="cursor:default" data-mem="${u.id}">${avatar(u, 40)}<span class="pn">${nameHtml(u)}${u.id === S.uid ? " (You)" : ""}<small>${admins.includes(u.id) ? "Group admin" : "@" + esc(u.username || "")}</small></span>
        ${amAdmin && u.id !== S.uid ? `<button class="chip-btn" data-mk="${u.id}">${admins.includes(u.id) ? "Remove admin" : "Make admin"}</button><button class="icon-btn small" data-rm="${u.id}" title="Remove">${icon("x", 15)}</button>` : ""}</div>`).join("")}</div>
      <button class="btn-danger" data-ga="leave">${icon("logout", 16)} Leave group</button>`, "");
    $("#modalCard").onclick = async e => {
      if (e.target.closest("[data-x]")) return closeModal();
      const ga = e.target.closest("[data-ga]")?.dataset.ga;
      const ref = doc(db, "chats", chatId);
      if (ga === "video" || ga === "voice") { closeModal(); if (S.chatId !== chatId) await openConversation({ chatId, isGroup: true }); return startMeetingFromChat(ga); }
      if (ga === "add") return addMembers(chatId, d);
      if (ga === "leave") {
        if (!confirm("Leave this group?")) return;
        const rest = (d.participants || []).filter(p => p !== S.uid);
        const upd = { participants: arrayRemove(S.uid), admins: arrayRemove(S.uid) };
        await sendToChat(chatId, { type: "system", text: `${S.me.displayName} left` }, { isGroup: true, participants: d.participants });
        if (amAdmin && (d.admins || []).length === 1 && rest.length) upd.admins = [rest[0]];
        await updateDoc(ref, upd).then(() => { toast("You left the group"); closeModal(); }).catch(() => toast("Could not leave", "err"));
        return;
      }
      if (e.target.closest("#giPhoto")) return $("#giFile").click();
      if (e.target.closest("#giSave")) {
        const name = $("#giName").value.trim(); if (!name) return;
        await updateDoc(ref, { name }).then(() => toast("Group updated", "ok")).catch(() => toast("Could not update", "err"));
        return;
      }
      const mk = e.target.closest("[data-mk]")?.dataset.mk;
      if (mk) { await updateDoc(ref, { admins: admins.includes(mk) ? arrayRemove(mk) : arrayUnion(mk) }).catch(() => toast("Failed", "err")); return; }
      const rm = e.target.closest("[data-rm]")?.dataset.rm;
      if (rm) {
        const u = users.find(x => x?.id === rm);
        if (!confirm(`Remove ${u?.displayName || "this member"}?`)) return;
        await updateDoc(ref, { participants: arrayRemove(rm), admins: arrayRemove(rm) }).catch(() => toast("Failed", "err"));
        await sendToChat(chatId, { type: "system", text: `${S.me.displayName} removed ${u?.displayName || "a member"}` }, { isGroup: true, participants: (d.participants || []).filter(p => p !== rm) });
      }
    };
    $("#giFile")?.addEventListener("change", async e => {
      const f = e.target.files[0]; if (!f) return;
      try { const up = await uploadFile(await compressImage(f, 512), "group photo"); await updateDoc(doc(db, "chats", chatId), { photoURL: up.secure_url }); toast("Group photo updated", "ok"); } catch (er) { toast(er.message, "err"); }
    });
  };
  // live while open
  const unsub = onSnapshot(doc(db, "chats", chatId), s => { if (s.exists() && !$("#modal").classList.contains("hidden") && $("#modalCard").querySelector("[data-mem]")) render(s.data()); }, () => {});
  const stop = new MutationObserver(() => { if ($("#modal").classList.contains("hidden")) { unsub(); stop.disconnect(); } });
  stop.observe($("#modal"), { attributes: true, attributeFilter: ["class"] });
  render(it?.data || S.chatDoc || { participants: [S.uid], name: "Group", admins: [] });
}

async function addMembers(chatId, d) {
  const contacts = (await contactUsers()).filter(u => !(d.participants || []).includes(u.id));
  const sel = new Set();
  openModal(`<div class="mc-head"><h3>Add members</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div class="pick-list">${contacts.length ? contacts.map(u => pickRow(u, false)).join("") : '<div class="empty-note">Everyone from your contacts is already in this group.</div>'}</div>
    <button class="btn-primary" id="amAdd" disabled>Add</button>`);
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    const pk = e.target.closest("[data-pk]");
    if (pk) { const id = pk.dataset.pk; sel.has(id) ? sel.delete(id) : sel.add(id); pk.classList.toggle("on", sel.has(id)); $("#amAdd").disabled = !sel.size; return; }
    if (e.target.closest("#amAdd")) {
      if ((d.participants || []).length + sel.size > MAX_MEMBERS) return toast("Too many members", "err");
      await updateDoc(doc(db, "chats", chatId), { participants: arrayUnion(...sel) }).catch(() => toast("Could not add", "err"));
      const names = contacts.filter(u => sel.has(u.id)).map(u => u.displayName).join(", ");
      await sendToChat(chatId, { type: "system", text: `${S.me.displayName} added ${names}` }, { isGroup: true, participants: [...(d.participants || []), ...sel] });
      closeModal(); toast("Members added", "ok");
    }
  };
}
