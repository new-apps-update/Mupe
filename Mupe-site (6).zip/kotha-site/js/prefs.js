import { $, icon, setSound } from "./utils.js";
import { ACCENTS } from "./config.js";

const KEY = "mupe-prefs-v3";
const DEF = { theme: "dark", accent: "mupe", wallpaper: "doodle", sound: true, desktop: true, fontScale: 1, enterSend: true };
let P = { ...DEF };
try { P = { ...DEF, ...JSON.parse(localStorage.getItem(KEY) || "{}") }; } catch { /* ignore */ }
try { const t = localStorage.getItem("mupe-theme"); if (t && !localStorage.getItem(KEY)) P.theme = t; } catch { /* ignore */ }

export const prefs = () => P;
export function setPref(k, v) {
  P[k] = v;
  try { localStorage.setItem(KEY, JSON.stringify(P)); localStorage.setItem("mupe-theme", P.theme); localStorage.setItem("mupe-accent", P.accent); } catch { /* ignore */ }
  applyPrefs();
}
export const effectiveTheme = () => P.theme === "auto" ? (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark") : P.theme;

export function applyPrefs() {
  const root = document.documentElement, t = effectiveTheme();
  root.dataset.theme = t; root.dataset.accent = ACCENTS[P.accent] ? P.accent : "mupe";
  root.style.fontSize = (15 * P.fontScale) + "px";
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", t === "dark" ? "#050605" : "#ffffff");
  const wp = $("#chatPane"); if (wp) wp.dataset.wp = P.wallpaper;
  const b = $("#themeBtn"); if (b) b.innerHTML = icon(t === "dark" ? "sun" : "moon", 20);
  setSound(P.sound);
}
matchMedia("(prefers-color-scheme: light)").addEventListener?.("change", () => { if (P.theme === "auto") applyPrefs(); });

/* ---------- desktop notifications ---------- */
export const notifSupported = () => "Notification" in window;
export async function askNotifPermission() {
  if (!notifSupported()) return "unsupported";
  if (Notification.permission === "default") { try { return await Notification.requestPermission(); } catch { return "denied"; } }
  return Notification.permission;
}
export function notify(title, body, { icon: ic, tag, onclick, silent = true } = {}) {
  try {
    if (!P.desktop || !notifSupported() || Notification.permission !== "granted") return;
    if (document.visibilityState === "visible" && document.hasFocus()) return;
    const n = new Notification(title, { body, icon: ic || "icons/icon-192.png", badge: "icons/icon-192.png", tag, silent, renotify: !!tag });
    n.onclick = () => { window.focus(); onclick?.(); n.close(); };
    setTimeout(() => n.close(), 8000);
  } catch { /* ignore */ }
}
