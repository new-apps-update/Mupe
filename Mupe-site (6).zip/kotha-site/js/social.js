// Notes (short text above your picture) and Stories (photo / video / text for 24 hours)
import { db, doc, setDoc, addDoc, updateDoc, deleteDoc, collection, query, where, onSnapshot, serverTimestamp, arrayUnion } from "./firebase.js";
import { S } from "./state.js";
import { STORY_MS } from "./config.js";
import { $, esc, avatar, icon, toast, openModal, closeModal, injectIcons } from "./utils.js";
import { getUser, openChat, sendToPeer } from "./chat.js";

const BGS = ["linear-gradient(135deg,#b4f52c,#5aa800)", "linear-gradient(135deg,#4f46e5,#9333ea)", "linear-gradient(135deg,#0284c7,#22d3ee)", "linear-gradient(135deg,#e11d48,#f97316)", "linear-gradient(135deg,#059669,#0891b2)", "linear-gradient(135deg,#334155,#0f172a)", "linear-gradient(135deg,#f59e0b,#ef4444)", "linear-gradient(135deg,#c026d3,#6366f1)"];
const ms = t => (t?.toMillis?.() ?? Date.now());
const ago = t => { const m = Math.floor((Date.now() - t) / 60000); return m < 1 ? "Just now" : m < 60 ? m + "m ago" : Math.floor(m / 60) + "h ago"; };
const alive = d => (d.expiresAt || 0) > Date.now();

let notes = new Map(), stories = new Map(), unsubs = [], audKey = "", timer = 0, started = false;
const U = new Map(), asked = new Set(), cleaned = new Set();

/* ---------- who can I see? my contacts (not blocked) + me ---------- */
function audience() {
  const blocked = new Set(S.me?.blocked || []);
  const ids = new Set([...(S.me?.contacts || []), ...S.chatItems.filter(i => !i.isGroup).map(i => i.otherId)]);
  ids.delete(S.uid);
  return [S.uid, ...[...ids].filter(id => id && !blocked.has(id)).slice(0, 89)];
}
function subscribe() {
  unsubs.forEach(u => u()); unsubs = [];
  const ids = audience(); audKey = ids.join(",");
  const chunks = []; for (let i = 0; i < ids.length; i += 30) chunks.push(ids.slice(i, i + 30));
  const nC = [], sC = [];
  const rebuild = () => {
    const now = Date.now();
    notes = new Map(nC.flat().filter(alive).map(n => [n.uid, n]));
    const all = sC.flat();
    all.filter(d => d.uid === S.uid && !alive(d) && !cleaned.has(d.id)).forEach(d => { cleaned.add(d.id); deleteDoc(doc(db, "stories", d.id)).catch(() => {}); });
    const map = new Map();
    all.filter(alive).sort((a, b) => ms(a.createdAt) - ms(b.createdAt)).forEach(d => { (map.get(d.uid) || map.set(d.uid, []).get(d.uid)).push(d); });
    stories = map; renderBar(); void now;
  };
  chunks.forEach((c, i) => {
    unsubs.push(onSnapshot(query(collection(db, "notes"), where("uid", "in", c)), s => { nC[i] = s.docs.map(d => ({ id: d.id, ...d.data() })); rebuild(); }, e => console.warn("notes", e.code)));
    unsubs.push(onSnapshot(query(collection(db, "stories"), where("uid", "in", c)), s => { sC[i] = s.docs.map(d => ({ id: d.id, ...d.data() })); rebuild(); }, e => console.warn("stories", e.code)));
  });
}
export function startSocial() {
  if (started) return; started = true;
  subscribe(); renderBar();
  timer = setInterval(() => { if (audience().join(",") !== audKey) subscribe(); else renderBar(); }, 20000);
}
export function stopSocial() {
  started = false; clearInterval(timer); unsubs.forEach(u => u()); unsubs = []; audKey = "";
  notes = new Map(); stories = new Map(); closeViewer(true);
  const b = $("#storyBar"); if (b) b.innerHTML = "";
}

/* ---------- the strip above the chat list ---------- */
function userOf(uid) {
  if (uid === S.uid) return S.me;
  if (U.has(uid)) return U.get(uid);
  if (!asked.has(uid)) { asked.add(uid); getUser(uid, 120000).then(u => { if (u) { U.set(uid, u); renderBar(); } }); }
  return { displayName: "…" };
}
const seenAll = list => list.every(s => (s.viewers || []).includes(S.uid));
function groups() {
  const ids = new Set([...stories.keys(), ...notes.keys()]); ids.delete(S.uid);
  const rows = [...ids].map(uid => ({ uid, user: userOf(uid), stories: stories.get(uid) || [], note: notes.get(uid) }));
  const t = r => Math.max(r.stories.length ? ms(r.stories.at(-1).createdAt) : 0, r.note ? ms(r.note.createdAt) : 0);
  const rank = r => r.stories.length ? (seenAll(r.stories) ? 1 : 0) : 2;
  return rows.sort((a, b) => rank(a) - rank(b) || t(b) - t(a));
}
function itemHtml({ uid, user, stories: st, note }, mine) {
  const ring = st.length ? (seenAll(st) && !mine ? "seen" : "new") : "none";
  return `<button class="st-item" data-st="${uid}">
    ${note ? `<span class="st-note">${esc(note.text)}</span>` : ""}
    <span class="st-av ${ring}">${avatar(user, 52)}${mine ? `<i class="st-plus">${icon("plus", 12)}</i>` : ""}</span>
    <span class="st-name">${mine ? "You" : esc((user.displayName || "").split(" ")[0])}</span></button>`;
}
export function renderBar() {
  const box = $("#storyBar"); if (!box || !S.me) return;
  const me = { uid: S.uid, user: S.me, stories: stories.get(S.uid) || [], note: notes.get(S.uid) };
  box.innerHTML = itemHtml(me, true) + groups().map(g => itemHtml(g, false)).join("");
}

/* ---------- my sheet: add story / note ---------- */
const sheetBtn = (id, ic, t, sub = "") => `<button class="sheet-btn" id="${id}"><span class="set-ic">${icon(ic, 18)}</span><span>${t}${sub ? `<small>${sub}</small>` : ""}</span></button>`;
function mySheet() {
  const my = stories.get(S.uid) || [], note = notes.get(S.uid);
  openModal(`<div class="mc-head"><h3>Your story &amp; note</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    ${sheetBtn("shAdd", "camera", "Add to story")}
    ${my.length ? sheetBtn("shView", "eye", "View my story", my.length + (my.length > 1 ? " updates" : " update")) : ""}
    ${sheetBtn("shNote", "pencil", note ? "Edit note" : "Add a note", note ? esc(note.text) : "")}`);
  $("#modalCard").onclick = e => {
    if (e.target.closest("[data-x]")) return closeModal();
    if (e.target.closest("#shAdd")) return storyComposer();
    if (e.target.closest("#shView")) { closeModal(); return openViewer(S.uid); }
    if (e.target.closest("#shNote")) return noteComposer();
  };
}

/* ---------- note ---------- */
function noteComposer() {
  const cur = notes.get(S.uid);
  openModal(`<div class="mc-head"><h3>Note</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <input id="ntText" maxlength="60" placeholder="Share a thought..." value="${esc(cur?.text || "")}" autocomplete="off">
    <div class="emoji-quick" id="ntEmo">${["😊", "😂", "❤️", "🔥", "😴", "🎧", "📚", "✈️"].map(e => `<button type="button">${e}</button>`).join("")}</div>
    <small class="muted center">Your contacts can see it for 24 hours.</small>
    <div class="row">${cur ? '<button class="btn-danger" id="ntDel">Delete</button>' : '<button class="btn-secondary" data-x>Cancel</button>'}<button class="btn-primary" id="ntSave">Share</button></div>`);
  const inp = $("#ntText"); inp.focus();
  $("#modalCard").onclick = async e => {
    if (e.target.closest("[data-x]")) return closeModal();
    const em = e.target.closest("#ntEmo button"); if (em) { if (inp.value.length < 58) inp.value += em.textContent; return inp.focus(); }
    if (e.target.closest("#ntDel")) { await deleteDoc(doc(db, "notes", S.uid)).catch(() => toast("Could not delete", "err")); return closeModal(); }
    if (e.target.closest("#ntSave")) {
      const text = inp.value.trim(); if (!text) return toast("Write something first", "err");
      const b = $("#ntSave"); b.disabled = true;
      try { await setDoc(doc(db, "notes", S.uid), { uid: S.uid, text, createdAt: serverTimestamp(), expiresAt: Date.now() + STORY_MS }); toast("Note shared", "ok"); closeModal(); }
      catch (er) { b.disabled = false; toast(er.code === "permission-denied" ? "Publish the latest firestore.rules first" : "Could not share note", "err", 5000); }
    }
  };
}
function noteView(uid) {
  const u = userOf(uid), n = notes.get(uid); if (!n) return;
  openModal(`<div class="mc-head"><h3>${esc(u.displayName)}'s note</h3><button class="icon-btn" data-x>${icon("x")}</button></div>
    <div style="align-self:center">${avatar(u, 84)}</div>
    <div class="note-big">${esc(n.text)}</div><small class="muted center">${ago(ms(n.createdAt))}</small>
    <div class="sv-reply"><input id="nvRep" maxlength="200" placeholder="Reply to note" autocomplete="off"><button class="send-btn" id="nvSend">${icon("send", 18)}</button></div>`);
  const send = async () => {
    const t = $("#nvRep").value.trim(); if (!t) return;
    if (await sendToPeer(uid, { type: "text", text: `↩️ Replied to your note “${n.text}”\n${t}` })) { toast("Reply sent", "ok"); closeModal(); }
  };
  $("#nvRep").addEventListener("keydown", e => { if (e.key === "Enter") send(); });
  $("#modalCard").onclick = e => { if (e.target.closest("[data-x]")) return closeModal(); if (e.target.closest("#nvSend")) send(); };
}

/* ---------- story composer ---------- */
function storyComposer() {
  let mode = "pick", file = null, kind = "", objUrl = "", bg = BGS[0], text = "";
  const head = `<div class="mc-head"><h3>New story</h3><button class="icon-btn" data-x>${icon("x")}</button></div>`;
  const foot = `<div class="row"><button class="btn-secondary" id="scBack">Back</button><button class="btn-primary" id="scPost">Post</button></div>`;
  const render = () => {
    if (mode === "pick") openModal(`${head}<div class="row"><button class="btn-secondary big" id="scMedia">${icon("image", 22)}<span>Photo / Video</span></button><button class="btn-secondary big" id="scText"><b style="font-size:22px">Aa</b><span>Text</span></button></div><input type="file" id="scFile" accept="image/*,video/*" class="hidden">`);
    else if (mode === "media") openModal(`${head}<div class="sc-preview">${kind === "video" ? `<video src="${objUrl}" controls playsinline muted></video>` : `<img src="${objUrl}" alt="">`}</div><input id="scCap" maxlength="120" placeholder="Add a caption" autocomplete="off">${foot}`);
    else openModal(`${head}<div class="sc-preview text" id="scBox" style="background:${bg}"><textarea id="scTxt" maxlength="180" placeholder="Type something">${esc(text)}</textarea></div><div class="swatches" id="scBgs">${BGS.map((g, i) => `<button class="swatch ${g === bg ? "on" : ""}" data-i="${i}" style="background:${g}"></button>`).join("")}</div>${foot}`);
    if (mode === "text") $("#scTxt").focus();
  };
  const setFile = f => {
    if (!f) return;
    const k = f.type.startsWith("video/") ? "video" : f.type.startsWith("image/") ? "image" : "";
    if (!k) return toast("Choose a photo or video", "err");
    if (k === "video" && f.size > 40 * 1024 * 1024) return toast("Video is too large (max 40 MB)", "err");
    const url = URL.createObjectURL(f);
    const go = () => { file = f; kind = k; objUrl = url; mode = "media"; render(); };
    if (k === "video") { const v = document.createElement("video"); v.preload = "metadata"; v.onloadedmetadata = () => v.duration > 31 ? toast("Videos can be up to 30 seconds", "err") : go(); v.onerror = go; v.src = url; } else go();
  };
  const post = async () => {
    const b = $("#scPost"); b.disabled = true; b.textContent = "Posting...";
    try {
      const d = { uid: S.uid, kind: mode === "text" ? "text" : kind, createdAt: serverTimestamp(), expiresAt: Date.now() + STORY_MS, viewers: [] };
      if (mode === "text") { d.text = $("#scTxt").value.trim(); d.bg = bg; if (!d.text) { b.disabled = false; b.textContent = "Post"; return toast("Type something first", "err"); } }
      else {
        const { uploadFile, compressImage } = await import("./attach.js");
        const up = await uploadFile(kind === "image" ? await compressImage(file, 1280) : file, "story");
        d.url = up.secure_url; const cap = $("#scCap")?.value.trim(); if (cap) d.caption = cap;
      }
      await addDoc(collection(db, "stories"), d);
      toast("Story posted", "ok"); closeModal();
    } catch (er) { b.disabled = false; b.textContent = "Post"; toast(er.code === "permission-denied" ? "Publish the latest firestore.rules first" : (er.message || "Could not post story"), "err", 5000); }
  };
  render();
  $("#modalCard").onclick = e => {
    if (e.target.closest("[data-x]")) return closeModal();
    if (e.target.closest("#scMedia")) return $("#scFile").click();
    if (e.target.closest("#scText")) { mode = "text"; return render(); }
    if (e.target.closest("#scBack")) { text = $("#scTxt")?.value || ""; mode = "pick"; return render(); }
    if (e.target.closest("#scPost")) return post();
    const sw = e.target.closest("#scBgs .swatch"); if (sw) { bg = BGS[+sw.dataset.i]; $("#scBox").style.background = bg; document.querySelectorAll("#scBgs .swatch").forEach(x => x.classList.toggle("on", x === sw)); }
  };
  $("#modalCard").onchange = e => { if (e.target.id === "scFile") setFile(e.target.files[0]); };
}

/* ---------- full-screen viewer ---------- */
const V = { q: [], ui: 0, si: 0, raf: 0, last: 0, elapsed: 0, dur: 5500, paused: false, loading: false };
const open = () => !$("#storyView").classList.contains("hidden");

export function openViewer(uid) {
  const q = [{ uid: S.uid, user: S.me, stories: stories.get(S.uid) || [] }, ...groups()].filter(x => x.stories.length).map(x => ({ ...x, stories: [...x.stories] }));
  const ui = q.findIndex(x => x.uid === uid); if (ui < 0) return;
  V.q = q; V.ui = ui;
  V.si = Math.max(0, q[ui].stories.findIndex(s => !(s.viewers || []).includes(S.uid)));
  $("#storyView").classList.remove("hidden"); showStory();
}
function stopTimer() { cancelAnimationFrame(V.raf); const v = $("#svMedia video"); if (v) { v.pause(); v.removeAttribute("src"); v.load(); } }
export function closeViewer(silent) {
  stopTimer(); $("#storyView").classList.add("hidden"); $("#svMedia").innerHTML = ""; $("#svSheet").classList.add("hidden");
  if (!silent) renderBar();
}
const setPaused = p => { V.paused = p; const v = $("#svMedia video"); if (v) p ? v.pause() : v.play().catch(() => {}); };
function next() { const g = V.q[V.ui]; if (V.si + 1 < g.stories.length) { V.si++; showStory(); } else nextUser(); }
function nextUser() { V.ui++; V.si = 0; V.ui >= V.q.length ? closeViewer() : showStory(); }
function prev() { if (V.si > 0) V.si--; else if (V.ui > 0) { V.ui--; V.si = 0; } showStory(); }

function showStory() {
  stopTimer();
  const g = V.q[V.ui], st = g?.stories[V.si]; if (!st) return closeViewer();
  const mine = g.uid === S.uid, user = mine ? S.me : userOf(g.uid);
  $("#svBars").innerHTML = g.stories.map((_, i) => `<i class="${i < V.si ? "done" : ""}"><b></b></i>`).join("");
  $("#svWho").innerHTML = `${avatar(user, 38)}<span><b>${esc(mine ? "Your story" : user.displayName)}</b><small>${ago(ms(st.createdAt))}</small></span>`;
  $("#svDel").classList.toggle("hidden", !mine);
  $("#svSheet").classList.add("hidden");
  const cap = st.caption ? `<div class="sv-cap">${esc(st.caption)}</div>` : "";
  $("#svMedia").innerHTML = st.kind === "text" ? `<div class="sv-text" style="background:${esc(st.bg || BGS[0])}"><p>${esc(st.text)}</p></div>`
    : st.kind === "video" ? `<video src="${esc(st.url)}" playsinline autoplay></video>${cap}` : `<img src="${esc(st.url)}" alt="">${cap}`;
  const n = (st.viewers || []).length;
  $("#svFoot").innerHTML = mine ? `<button class="sv-views" id="svViews">${icon("eye", 18)} ${n} ${n === 1 ? "view" : "views"}</button>`
    : `<div class="sv-emo">${["❤️", "😂", "😮", "😢", "👍", "🔥"].map(e => `<button data-emo="${e}">${e}</button>`).join("")}</div><div class="sv-reply"><input id="svRep" maxlength="200" placeholder="Reply to ${esc((user.displayName || "").split(" ")[0])}" autocomplete="off"><button class="send-btn" id="svSend">${icon("send", 18)}</button></div>`;
  if (!mine && !(st.viewers || []).includes(S.uid)) {
    st.viewers = [...(st.viewers || []), S.uid];
    updateDoc(doc(db, "stories", st.id), { viewers: arrayUnion(S.uid) }).catch(() => {});
  }
  // progress
  V.paused = false; V.elapsed = 0; V.loading = false; V.last = performance.now();
  const bar = $("#svBars").children[V.si]?.firstElementChild, vid = $("#svMedia video"), img = $("#svMedia img");
  if (vid) {
    vid.ontimeupdate = () => { if (vid.duration && bar) bar.style.width = (vid.currentTime / vid.duration * 100) + "%"; };
    vid.onended = next; vid.onerror = next;
    vid.play().catch(() => { vid.muted = true; vid.play().catch(() => {}); });
    return;
  }
  if (img && !img.complete) { V.loading = true; img.onload = img.onerror = () => { V.loading = false; V.last = performance.now(); }; }
  V.dur = st.kind === "text" ? Math.min(9000, 4000 + (st.text || "").length * 45) : 5500;
  const loop = ts => {
    if (!V.paused && !V.loading) V.elapsed += ts - V.last;
    V.last = ts;
    const f = Math.min(1, V.elapsed / V.dur); if (bar) bar.style.width = f * 100 + "%";
    if (f >= 1) next(); else V.raf = requestAnimationFrame(loop);
  };
  V.raf = requestAnimationFrame(loop);
}

async function viewersSheet() {
  const st = V.q[V.ui]?.stories[V.si]; if (!st) return;
  setPaused(true);
  const sh = $("#svSheet"); sh.classList.remove("hidden");
  sh.innerHTML = `<div class="mc-head"><h3>Viewed by ${(st.viewers || []).length}</h3><button class="icon-btn" id="svSheetX">${icon("x")}</button></div><div class="pick-list">Loading...</div>`;
  const us = (await Promise.all((st.viewers || []).map(id => getUser(id, 60000)))).filter(Boolean);
  sh.querySelector(".pick-list").innerHTML = us.map(u => `<div class="pick" style="cursor:default">${avatar(u, 40)}<span class="pn">${esc(u.displayName)}<small>@${esc(u.username || "")}</small></span></div>`).join("") || '<div class="empty-note">No views yet.</div>';
}
async function deleteCurrent() {
  const g = V.q[V.ui], st = g?.stories[V.si]; if (!st || !confirm("Delete this story?")) return;
  setPaused(true);
  try { await deleteDoc(doc(db, "stories", st.id)); } catch { setPaused(false); return toast("Could not delete", "err"); }
  g.stories.splice(V.si, 1);
  if (!g.stories.length) { V.q.splice(V.ui, 1); V.si = 0; if (V.ui >= V.q.length) return closeViewer(); }
  else if (V.si >= g.stories.length) { V.si = 0; V.ui++; if (V.ui >= V.q.length) return closeViewer(); }
  showStory();
}
async function reply(text) {
  const g = V.q[V.ui]; if (!g || !text) return false;
  const ok = await sendToPeer(g.uid, { type: "text", text: `↩️ Replied to your story\n${text}` });
  if (ok) toast("Sent", "ok"); return ok;
}

export function initSocial() {
  $("#storyBar").addEventListener("click", e => {
    const b = e.target.closest("[data-st]"); if (!b) return;
    const uid = b.dataset.st;
    if (uid === S.uid) return mySheet();
    if (stories.get(uid)?.length) return openViewer(uid);
    noteView(uid);
  });
  $("#svClose").onclick = () => closeViewer();
  $("#svDel").onclick = deleteCurrent;
  // tap = next/previous, press and hold = pause
  [["#svPrev", prev], ["#svNext", next]].forEach(([sel, fn]) => {
    const b = $(sel); let t0 = 0;
    b.addEventListener("pointerdown", () => { t0 = Date.now(); setPaused(true); });
    b.addEventListener("pointerup", () => { setPaused(false); if (Date.now() - t0 < 250) fn(); });
    b.addEventListener("pointerleave", () => { if (V.paused && $("#svSheet").classList.contains("hidden") && document.activeElement?.id !== "svRep") setPaused(false); });
  });
  $("#svFoot").addEventListener("click", async e => {
    if (e.target.closest("#svViews")) return viewersSheet();
    const em = e.target.closest("[data-emo]"); if (em) return void reply(em.dataset.emo);
    if (e.target.closest("#svSend")) { const i = $("#svRep"); if (await reply(i.value.trim())) i.value = ""; }
  });
  $("#svFoot").addEventListener("keydown", async e => { if (e.target.id === "svRep" && e.key === "Enter") { if (await reply(e.target.value.trim())) e.target.value = ""; } });
  $("#svFoot").addEventListener("focusin", e => { if (e.target.id === "svRep") setPaused(true); });
  $("#svFoot").addEventListener("focusout", e => { if (e.target.id === "svRep") setPaused(false); });
  $("#svSheet").addEventListener("click", e => { if (e.target.closest("#svSheetX")) { $("#svSheet").classList.add("hidden"); setPaused(false); } });
  document.addEventListener("keydown", e => { if (!open()) return; if (e.key === "Escape") closeViewer(); else if (e.key === "ArrowRight") next(); else if (e.key === "ArrowLeft") prev(); });
  injectIcons($("#storyView"));
}
