// Shared app state
export const S = {
  user: null,        // firebase auth user
  uid: null,
  me: null,          // my profile doc (live)
  isOwner: false,
  // open chat
  chatId: null,
  chatDoc: null,
  isGroup: false,
  peerId: null,      // 1:1 only
  peer: null,        // 1:1 only
  members: new Map(),// uid -> user (group + 1:1)
  msgs: [],
  msgLimit: 150,
  replyTo: null,
  editing: null,
  chatItems: [],
  knownChats: new Set(),
  chatExists: false
};
