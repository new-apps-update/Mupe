import { OWNER } from "./config.js";

export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const chatIdOf = (a, b) => [a, b].sort().join("_");
export const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const isCoarse = () => matchMedia("(pointer:coarse)").matches;
export const isMobile = () => matchMedia("(max-width:860px)").matches;
export const haptic = (ms = 12) => { try { navigator.vibrate?.(ms); } catch { /* ignore */ } };
export const rid = (n = 8) => { const c = "abcdefghjkmnpqrstuvwxyz23456789"; let s = ""; const a = crypto.getRandomValues(new Uint8Array(n)); a.forEach(v => { s += c[v % c.length]; }); return s; };

/* ---------- Icons ---------- */
const I = {
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
  endcall: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
  video: '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
  "video-off": '<path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34l1 1L23 7v10"/><line x1="1" y1="1" x2="23" y2="23"/>',
  send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  mic: '<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>',
  "mic-off": '<line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>',
  clip: '<path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
  smile: '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>',
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  more: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
  chevron: '<polyline points="6 9 12 15 18 9"/>',
  "chevron-right": '<polyline points="9 18 15 12 9 6"/>',
  "arrow-down": '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  sun: '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  compose: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  reply: '<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>',
  forward: '<polyline points="15 17 20 12 15 7"/><path d="M4 18v-2a4 4 0 0 1 4-4h12"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  pencil: '<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>',
  play: '<polygon points="6 3 20 12 6 21 6 3" fill="currentColor"/>',
  pause: '<rect x="6" y="4" width="4" height="16" fill="currentColor"/><rect x="14" y="4" width="4" height="16" fill="currentColor"/>',
  file: '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
  ban: '<circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  "user-plus": '<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  checks: '<polyline points="1 13 6 18 16 6"/><polyline points="9 15 12 18 22 6"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  pin: '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
  monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
  "bell-off": '<path d="M13.73 21a2 2 0 0 1-3.46 0"/><path d="M18.63 13A17.89 17.89 0 0 1 18 8"/><path d="M6.26 6.26A5.86 5.86 0 0 0 6 8c0 7-3 9-3 9h14"/><path d="M18 8a6 6 0 0 0-9.33-5"/><line x1="1" y1="1" x2="23" y2="23"/>',
  archive: '<polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  refresh: '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  chat: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
  compass: '<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  poll: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  volume: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>',
  locate: '<circle cx="12" cy="12" r="10"/><line x1="22" y1="12" x2="18" y2="12"/><line x1="6" y1="12" x2="2" y2="12"/><line x1="12" y1="6" x2="12" y2="2"/><line x1="12" y1="22" x2="12" y2="18"/>',
  hand: '<path d="M18 11V6a2 2 0 0 0-4 0v1M14 10V4a2 2 0 0 0-4 0v6M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/>',
  palette: '<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 0 0 0 20 2 2 0 0 0 2-2c0-.5-.2-1-.5-1.4a2 2 0 0 1 1.5-3.3H17a5 5 0 0 0 5-5C22 6 17.5 2 12 2z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
  layout: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>',
  smilepl: '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
  heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>'
};
export const icon = (n, s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[n] || ""}</svg>`;
export function injectIcons(root = document) {
  $$("[data-icon]", root).forEach(e => { e.innerHTML = icon(e.dataset.icon, +e.dataset.size || 20); });
}

/* ---------- Animated logo ---------- */
let logoId = 0;
export function logoSVG() {
  const id = "lg" + (++logoId);
  return `<svg viewBox="330 330 1388 1388" xmlns="http://www.w3.org/2000/svg" aria-label="Mupe" role="img"><defs>
<linearGradient id="${id}f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b9f628"/><stop offset="1" stop-color="#9be200"/></linearGradient>
<linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".7"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
<clipPath id="${id}c"><circle cx="1023.5" cy="1023.5" r="693"/></clipPath>
<clipPath id="${id}g"><path d="M783.0 1499.0 L774.0 1497.4 L765.0 1492.1 L758.7 1485.0 L754.8 1476.0 L753.8 1362.0 L724.0 1349.3 L703.0 1337.2 L681.7 1321.0 L661.0 1300.6 L644.8 1279.0 L630.8 1254.0 L620.9 1228.0 L614.8 1201.0 L611.7 1160.0 L611.9 723.0 L614.7 701.0 L620.9 681.0 L631.0 661.1 L643.0 645.1 L660.0 629.7 L680.0 617.6 L698.0 610.7 L721.0 606.4 L746.0 606.4 L769.0 610.8 L787.0 617.8 L806.9 630.0 L821.0 642.4 L832.1 656.0 L1014.5 918.0 L1013.0 922.0 L989.1 954.0 L979.0 964.1 L966.0 973.3 L954.0 979.3 L940.0 983.0 L922.0 983.6 L909.0 981.2 L888.0 972.3 L873.0 960.7 L793.3 848.0 L785.0 838.1 L778.0 834.7 L769.4 835.0 L761.9 839.0 L756.9 846.0 L754.9 855.0 L754.5 870.0 L754.6 1163.0 L755.8 1180.0 L758.9 1193.0 L764.0 1204.9 L771.0 1216.0 L780.4 1226.0 L789.0 1232.4 L799.0 1237.3 L827.0 1244.5 L833.0 1248.7 L836.3 1253.0 L838.5 1261.0 L838.8 1325.0 L840.0 1327.5 L934.0 1256.8 L948.0 1247.7 L958.0 1243.9 L970.0 1242.9 L1228.0 1242.7 L1250.0 1237.1 L1259.5 1232.0 L1269.0 1224.6 L1277.4 1215.0 L1285.6 1201.0 L1290.3 1187.0 L1292.5 1170.0 L1292.4 859.0 L1289.6 844.0 L1281.0 833.0 L1293.3 815.0 L1306.0 802.0 L1322.0 790.9 L1337.0 784.9 L1356.0 782.3 L1374.0 784.7 L1389.0 790.9 L1404.0 801.6 L1415.2 814.0 L1425.1 831.0 L1432.2 850.0 L1435.1 868.0 L1435.3 1174.0 L1430.2 1213.0 L1419.4 1247.0 L1404.3 1276.0 L1383.2 1304.0 L1358.0 1327.2 L1324.0 1349.2 L1296.7 1360.0 L1261.0 1367.9 L1233.0 1370.3 L972.0 1370.3 L962.0 1371.9 L949.0 1379.7 L801.0 1493.5 L792.0 1497.8ZM1028.0 1109.0 L1011.0 1108.2 L995.0 1104.2 L979.0 1097.2 L965.0 1087.2 L947.8 1069.0 L895.1 993.0 L897.0 992.2 L911.0 996.1 L925.0 997.8 L938.0 997.5 L950.0 995.3 L962.0 991.1 L975.0 984.3 L985.0 977.2 L997.0 966.0 L1008.1 953.0 L1027.4 926.0 L1214.7 657.0 L1227.0 642.2 L1241.0 629.9 L1257.0 619.8 L1273.0 612.7 L1296.0 607.0 L1314.0 605.6 L1330.0 606.7 L1353.0 611.7 L1370.0 618.9 L1389.0 630.8 L1403.0 643.5 L1414.4 658.0 L1424.3 676.0 L1431.3 696.0 L1435.5 724.0 L1435.0 816.2 L1421.0 798.9 L1408.0 786.7 L1392.0 776.6 L1376.0 770.6 L1356.0 768.4 L1338.0 770.5 L1320.0 776.6 L1303.0 786.5 L1289.8 798.0 L1277.7 813.0 L1095.3 1074.0 L1081.0 1088.6 L1066.9 1098.0 L1046.0 1106.3Z" clip-rule="evenodd"/></clipPath>
<mask id="${id}m" maskUnits="userSpaceOnUse" x="300" y="300" width="1450" height="1450"><path class="lpen" pathLength="100" d="M797 1462L960 1306L1190 1303Q1363 1300 1363 1130L1363 780Q1363 672 1290 686L1016 1010L790 715Q760 668 722 690Q682 706 682 790L682 1130Q682 1290 800 1330L800 1400" fill="none" stroke="#fff" stroke-width="210" stroke-linecap="round" stroke-linejoin="round"/></mask></defs>
<g class="lcirc"><circle cx="1023.5" cy="1023.5" r="693" fill="url(#${id}f)"/><g clip-path="url(#${id}c)"><rect class="lshine" x="-300" y="300" width="360" height="1500" fill="url(#${id}s)" transform="skewX(-16)"/></g></g>
<g class="lglyph"><g mask="url(#${id}m)"><path d="M783.0 1499.0 L774.0 1497.4 L765.0 1492.1 L758.7 1485.0 L754.8 1476.0 L753.8 1362.0 L724.0 1349.3 L703.0 1337.2 L681.7 1321.0 L661.0 1300.6 L644.8 1279.0 L630.8 1254.0 L620.9 1228.0 L614.8 1201.0 L611.7 1160.0 L611.9 723.0 L614.7 701.0 L620.9 681.0 L631.0 661.1 L643.0 645.1 L660.0 629.7 L680.0 617.6 L698.0 610.7 L721.0 606.4 L746.0 606.4 L769.0 610.8 L787.0 617.8 L806.9 630.0 L821.0 642.4 L832.1 656.0 L1014.5 918.0 L1013.0 922.0 L989.1 954.0 L979.0 964.1 L966.0 973.3 L954.0 979.3 L940.0 983.0 L922.0 983.6 L909.0 981.2 L888.0 972.3 L873.0 960.7 L793.3 848.0 L785.0 838.1 L778.0 834.7 L769.4 835.0 L761.9 839.0 L756.9 846.0 L754.9 855.0 L754.5 870.0 L754.6 1163.0 L755.8 1180.0 L758.9 1193.0 L764.0 1204.9 L771.0 1216.0 L780.4 1226.0 L789.0 1232.4 L799.0 1237.3 L827.0 1244.5 L833.0 1248.7 L836.3 1253.0 L838.5 1261.0 L838.8 1325.0 L840.0 1327.5 L934.0 1256.8 L948.0 1247.7 L958.0 1243.9 L970.0 1242.9 L1228.0 1242.7 L1250.0 1237.1 L1259.5 1232.0 L1269.0 1224.6 L1277.4 1215.0 L1285.6 1201.0 L1290.3 1187.0 L1292.5 1170.0 L1292.4 859.0 L1289.6 844.0 L1281.0 833.0 L1293.3 815.0 L1306.0 802.0 L1322.0 790.9 L1337.0 784.9 L1356.0 782.3 L1374.0 784.7 L1389.0 790.9 L1404.0 801.6 L1415.2 814.0 L1425.1 831.0 L1432.2 850.0 L1435.1 868.0 L1435.3 1174.0 L1430.2 1213.0 L1419.4 1247.0 L1404.3 1276.0 L1383.2 1304.0 L1358.0 1327.2 L1324.0 1349.2 L1296.7 1360.0 L1261.0 1367.9 L1233.0 1370.3 L972.0 1370.3 L962.0 1371.9 L949.0 1379.7 L801.0 1493.5 L792.0 1497.8ZM1028.0 1109.0 L1011.0 1108.2 L995.0 1104.2 L979.0 1097.2 L965.0 1087.2 L947.8 1069.0 L895.1 993.0 L897.0 992.2 L911.0 996.1 L925.0 997.8 L938.0 997.5 L950.0 995.3 L962.0 991.1 L975.0 984.3 L985.0 977.2 L997.0 966.0 L1008.1 953.0 L1027.4 926.0 L1214.7 657.0 L1227.0 642.2 L1241.0 629.9 L1257.0 619.8 L1273.0 612.7 L1296.0 607.0 L1314.0 605.6 L1330.0 606.7 L1353.0 611.7 L1370.0 618.9 L1389.0 630.8 L1403.0 643.5 L1414.4 658.0 L1424.3 676.0 L1431.3 696.0 L1435.5 724.0 L1435.0 816.2 L1421.0 798.9 L1408.0 786.7 L1392.0 776.6 L1376.0 770.6 L1356.0 768.4 L1338.0 770.5 L1320.0 776.6 L1303.0 786.5 L1289.8 798.0 L1277.7 813.0 L1095.3 1074.0 L1081.0 1088.6 L1066.9 1098.0 L1046.0 1106.3Z" fill="#060806" fill-rule="evenodd"/></g>
<circle class="lflash" cx="1023.5" cy="1023.5" r="693" fill="none" stroke="#d7ff6b"/></g></svg>`;
}
export function injectLogos(root = document) {
  $$("[data-logo],[data-logo-mini]", root).forEach(e => { if (!e.firstChild) e.innerHTML = logoSVG(); });
}

/* ---------- Owner badge ---------- */
let ownerSelf = null; // uid of the logged-in user when their Google email matches OWNER.email
export const setOwnerSelf = uid => { ownerSelf = uid; };
export const isOwnerUser = u => !!u && (OWNER.uids.includes(u.id || u.uid) || (!!ownerSelf && (u.id || u.uid) === ownerSelf));
export const ownerBadge = (size = 15) => `<span class="owner-badge" title="Verified owner of Mupe - ${esc(OWNER.name)}"><svg width="${size}" height="${size}" viewBox="0 0 24 24"><defs><linearGradient id="ob" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#38bdf8"/><stop offset="1" stop-color="#6366f1"/></linearGradient></defs><path fill="url(#ob)" d="M12 1.5l2.6 1.9 3.2-.1 1 3 2.6 1.9-1 3 1 3-2.6 1.9-1 3-3.2-.1L12 22.5l-2.6-1.9-3.2.1-1-3-2.6-1.9 1-3-1-3 2.6-1.9 1-3 3.2.1z"/><path d="M8 12.2l2.6 2.6L16.2 9" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`;
export const nameHtml = u => esc(u?.displayName || "") + (isOwnerUser(u) ? ownerBadge(14) : "");

/* ---------- Avatars ---------- */
const COLORS = [["#06b6d4", "#3b82f6"], ["#8b5cf6", "#ec4899"], ["#f59e0b", "#ef4444"], ["#10b981", "#06b6d4"], ["#6366f1", "#a855f7"], ["#14b8a6", "#84cc16"], ["#f43f5e", "#fb923c"], ["#0ea5e9", "#22c55e"]];
export const colorOf = key => { let h = 0; for (const c of String(key || "?")) h = (h * 31 + c.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
export function avatar(u, size = 44) {
  const name = u?.displayName || u?.name || "?";
  const st = `width:${size}px;height:${size}px`;
  if (u?.photoURL) return `<img class="av" src="${esc(u.photoURL)}" style="${st}" alt="${esc(name)}" referrerpolicy="no-referrer" loading="lazy" onerror="this.outerHTML=window.__avFallback(this.alt,${size},${u.isGroup ? 1 : 0})">`;
  return avFallback(name, size, u?.isGroup ? 1 : 0);
}
function avFallback(name, size, group) {
  const c = colorOf(name);
  const ini = name.trim().split(/\s+/).slice(0, 2).map(w => [...w][0] || "").join("").toUpperCase() || "?";
  const inner = group ? icon("users", Math.round(size * .48)) : esc(ini);
  return `<div class="av" style="width:${size}px;height:${size}px;font-size:${Math.round(size * .4)}px;background:linear-gradient(135deg,${c[0]},${c[1]})">${inner}</div>`;
}
window.__avFallback = avFallback;

/* ---------- Time ---------- */
export const timeShort = ms => new Date(ms).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
const dayDiff = ms => {
  const d = new Date(ms), n = new Date();
  return Math.round((new Date(n.getFullYear(), n.getMonth(), n.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
};
export function dayLabel(ms) {
  const dd = dayDiff(ms);
  if (dd === 0) return "Today";
  if (dd === 1) return "Yesterday";
  const d = new Date(ms);
  return d.toLocaleDateString([], { day: "numeric", month: "short", year: d.getFullYear() !== new Date().getFullYear() ? "numeric" : undefined });
}
export function listTime(ms) {
  if (!ms) return "";
  const dd = dayDiff(ms);
  if (dd === 0) return timeShort(ms);
  if (dd === 1) return "Yesterday";
  if (dd < 7) return new Date(ms).toLocaleDateString([], { weekday: "short" });
  return new Date(ms).toLocaleDateString([], { day: "numeric", month: "short" });
}
export const lastMs = u => u?.lastSeen?.toMillis?.() ?? 0;
export const isOnline = u => !!u?.online && Date.now() - lastMs(u) < 80000 && u?.privacy?.lastSeen !== "nobody";
export function presenceText(u) {
  if (u?.privacy?.lastSeen === "nobody") return "";
  if (isOnline(u)) return "online";
  const ms = lastMs(u);
  if (!ms) return "offline";
  return "last seen " + (dayDiff(ms) === 0 ? "today at " + timeShort(ms) : dayLabel(ms) + " at " + timeShort(ms));
}
export const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); const h = Math.floor(s / 3600); s %= 3600; return (h ? h + ":" + String(Math.floor(s / 60)).padStart(2, "0") : Math.floor(s / 60)) + ":" + String(s % 60).padStart(2, "0"); };
export const fmtSize = b => !b ? "" : b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(0) + " KB" : (b / 1048576).toFixed(1) + " MB";
export const fileExt = n => ((n || "").split(".").pop() || "").toLowerCase().slice(0, 5);
export function fileKind(name, mime = "") {
  const e = fileExt(name);
  if (mime.startsWith("image/") || ["jpg", "jpeg", "png", "gif", "webp", "heic", "avif"].includes(e)) return "image";
  if (mime.startsWith("video/") || ["mp4", "mov", "webm", "mkv", "3gp"].includes(e)) return "video";
  if (mime.startsWith("audio/") || ["mp3", "m4a", "wav", "ogg", "opus", "aac"].includes(e)) return "audio";
  return "file";
}
export const docTone = e => ({ pdf: "#ef4444", doc: "#2563eb", docx: "#2563eb", xls: "#16a34a", xlsx: "#16a34a", csv: "#16a34a", ppt: "#f97316", pptx: "#f97316", zip: "#a855f7", rar: "#a855f7", txt: "#64748b", apk: "#22c55e" }[e] || "#6366f1");

/* ---------- Sounds ---------- */
let ac;
export function audioCtx() {
  try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === "suspended") ac.resume(); } catch { /* ignore */ }
  return ac;
}
export function tone(freq, start, dur, vol = .08, type = "sine") {
  try {
    const c = audioCtx(); if (!c) return;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = freq;
    o.connect(g); g.connect(c.destination);
    const t = c.currentTime + start;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + .02);
    g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.start(t); o.stop(t + dur + .05);
  } catch { /* ignore */ }
}
let soundOn = true;
export const setSound = v => { soundOn = !!v; };
export function beep(kind = "in") {
  if (!soundOn) return;
  if (kind === "in") { tone(880, 0, .14); tone(1175, .12, .22); }
  else if (kind === "send") tone(660, 0, .1, .05);
  else if (kind === "join") { tone(660, 0, .12, .06); tone(880, .1, .18, .06); }
  else if (kind === "leave") { tone(880, 0, .12, .06); tone(520, .1, .2, .06); }
}

/* ---------- Toast ---------- */
export function toast(msg, type = "", ms = 3200) {
  const t = document.createElement("div");
  t.className = "toast " + type; t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 350); }, ms);
}

/* ---------- Search keywords ---------- */
export function makeKeywords(name, username) {
  const set = new Set();
  const words = [...name.toLowerCase().split(/\s+/).filter(Boolean), username.toLowerCase()];
  words.forEach(w => { for (let i = 1; i <= Math.min(w.length, 14); i++) set.add(w.slice(0, i)); });
  return [...set];
}

/* ---------- Modal / sheets ---------- */
export function openModal(html, cls = "") {
  const c = $("#modalCard");
  c.className = "modal-card " + cls;
  c.innerHTML = html;
  injectIcons(c); injectLogos(c);
  $("#modal").classList.remove("hidden");
}
export function closeModal() { $("#modal").classList.add("hidden"); $("#modalCard").innerHTML = ""; $("#modalCard").onclick = null; }

export async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch {
    try { const a = document.createElement("textarea"); a.value = t; document.body.appendChild(a); a.select(); document.execCommand("copy"); a.remove(); return true; } catch { return false; }
  }
}
export const linkify = s => esc(s).replace(/(https?:\/\/[^\s<]+)/g, u => `<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>`);
